NASfVI - Natürlichsprachiges Anfragesystem für Vorlesungs-
verzeichnisse im Internet

Mit NASfVI können verschiedene Anfragen in natürlichem Deutsch an ein
Vorlesungsverzeichnis gestellt werden. Diesem Quellcode liegen
Vorlesungsdaten des Centrums für Informations- und Sprachverarbeitung der
Luwdig-Maximilians-Universität München bei.

In dieser Datei werden stichpunktartig die Voraussetzungen für die
Installation und den Betrieb von NASfVI aufgelistet, sowie erklärt, wie
NASfVI mit Apache Ant installiert werden kann. Unter Installation ist dabei
jedoch nur zu verstehen, dass der Quellcode kompiliert wird und NASfVI
mit einer im gleichen Verzeichnis befindlichen jetty-Instanz genutzt werden
kann.

Voraussetzungen:

- Eine Laufzeitumgebung für Java 6 muss vorhanden sein
- SWI-Prolog muss installiert sein (http://www.swi-prolog.org/)
- Für die Installation mit Apache Ant muss Apache Ant installiert
sein (http://ant.apache.org/)

Installation:

1. jetty herunterladen (http://www.eclipse.org/jetty/)
    - jetty entpacken und in das Verzeichnis von NASfVI verschieben
    - das Verzeichnis von jetty in "jetty" umbenennen

2. Das Google Web Toolkit SDK (GWT SDK) herunterladen
   (http://code.google.com/intl/de/webtoolkit/download.html)
    - das GWT SDK entpacken und in das Verzeichnis von NASfVI verschieben
    - das Verzeichnis des GWT SDK in "gwt" umbenennen

3. In das Verzeichnis von NASfVI wechseln und Apache Ant mit
   dem Befehl "ant" oder "ant install" aufrufen.

Starten von NASfVI:

Um NASfVI zu starten, muss in das Verzeichnis von jetty gewechselt werden.
jetty und NASfVI können mit dem folgenden Befehl gestartet werden:

java -server -Djava.library.path=PFAD_JPL -jar start.jar

Dabei muss PFAD_JPL durch den absoluten Pfad zur Installation von SWI-Prolog
ersetzt werden.
