////////////////////////////////////////////////////////////////////////////////
//
//          StatDZE    -    www.partusch.de.vu
//          Copyright(c) Stefan Partusch
//
//          Program: StatDZE / Version 1.0.0
//          License: See license.txt (english) or lizenz.txt (deutsch)
//                   Absolutely NO WARRANTY and NO SUPPORT! Use this source at
//                   your very own risk.
//          Date:    2004/06/28

#include <windows.h>
#include "gui_toolwindows.h"
#include "gui_functions.h"
#include "gui_tabchildproc.h"
#include "gui_main.h"

HWND CreateToolWindow(HWND  hParent, const TCHAR* szName, WNDPROC WndProc){
    HINSTANCE    hInstance;
    HWND         hwnd;
    WNDCLASS     wndclass;
    
    if((szName == NULL) || (WndProc == NULL)) return NULL;
    if(hParent)
        hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);
    else
        hInstance = NULL;
    
    if(hwnd = FindWindow(szName,szName)){
        if(hParent == (HWND)GetWindowLong(hwnd,GWL_HWNDPARENT)){
                SetForegroundWindow(hwnd);
                return NULL;
        }
    }
     
    wndclass.style         = CS_HREDRAW | CS_VREDRAW;
    wndclass.lpfnWndProc   = WndProc;
    wndclass.cbClsExtra    = 0;
    wndclass.cbWndExtra    = 0;
    wndclass.hInstance     = hInstance;
    wndclass.hIcon         = NULL;
    wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
    wndclass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wndclass.lpszMenuName  = NULL;
    wndclass.lpszClassName = szName;
    
    RegisterClass(&wndclass);

    hwnd = CreateWindowEx(WS_EX_TOOLWINDOW, szName, szName,
                          WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                          0,0,0,0,hParent,NULL,hInstance,NULL);

    ShowWindow(hwnd, SW_NORMAL);
    UpdateWindow(hwnd);
    return hwnd;
}


LRESULT CALLBACK WndSettingsProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam){
PAINTSTRUCT      ps;
HDC              hdc;
TEXTMETRIC       tm;
LOGFONT          lf;
TCHAR            szBuffer[16];
static HWND      hChild[7], hParent, hGroup;
static int       iTheme, iOldTheme, iUpdate, iPopupTime, iChHeight, iChWidth, i;
static BOOL      bPopup;
static HFONT     hFont;
static HINSTANCE hInstance;
static HBRUSH    hBrush;


     switch (message){
          case WM_CREATE:
               hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);
               GetSettings(&iTheme,&iUpdate,&iPopupTime,&bPopup,NULL,NULL,NULL,NULL,NULL);
               iOldTheme = iTheme;
               hParent = (HWND)GetWindowLong(hwnd,GWL_HWNDPARENT);
               
               hdc = GetDC(hwnd);
               SelectObject(hdc,GetStockObject(ANSI_FIXED_FONT));
               SetMapMode(hdc,MM_TEXT);
               GetTextMetrics(hdc,&tm);
               iChHeight = tm.tmHeight;
               iChWidth = tm.tmMaxCharWidth;

               ZeroMemory(&lf,sizeof(lf));
               lf.lfHeight = -MulDiv(22, GetDeviceCaps(hdc, LOGPIXELSY), 72);
               //lf.lfWeight = FW_BOLD;
               lf.lfQuality = ANTIALIASED_QUALITY;
               lf.lfUnderline = TRUE;
               lf.lfCharSet = tm.tmCharSet;
               lf.lfPitchAndFamily = tm.tmPitchAndFamily;
               //GetTextFace(hdc,LF_FACESIZE,lf.lfFaceName);
               lstrcpy(lf.lfFaceName,TEXT("Arial"));
               hFont = CreateFontIndirect(&lf);
               ReleaseDC(hwnd,hdc);
               
               hChild[IMILSERV] = CreateWindow(TEXT("button"),TEXT("... milit�rischen Dienst"),BS_AUTORADIOBUTTON|WS_VISIBLE|WS_CHILD,0,0,0,0,hwnd,(HMENU)(int)(100+IMILSERV),hInstance,NULL);
               hChild[ICIVSERV] = CreateWindow(TEXT("button"),TEXT("... zivilen Dienst"),BS_AUTORADIOBUTTON|WS_VISIBLE|WS_CHILD,0,0,0,0,hwnd,(HMENU)(int)(100+ICIVSERV),hInstance,NULL);
               hGroup = CreateWindow(TEXT("button"),TEXT(""),BS_GROUPBOX|WS_CHILD,0,0,0,0,hwnd,(HMENU)(int)(200),hInstance,NULL);

               hChild[IPOPUP] = CreateWindow(TEXT("button"),TEXT("Restzeit nach dem Anmelden einblenden"),BS_AUTOCHECKBOX|WS_VISIBLE|WS_CHILD,0,0,0,0,hwnd,(HMENU)(int)(100+IPOPUP),hInstance,NULL);
               hChild[IOK] = CreateWindow(TEXT("button"),TEXT("OK"),BS_DEFPUSHBUTTON|WS_VISIBLE|WS_CHILD,0,0,0,0,hwnd,(HMENU)(int)(100+IOK),hInstance,NULL);
               hChild[IABORT] = CreateWindow(TEXT("button"),TEXT("Abbrechen"),BS_DEFPUSHBUTTON|WS_VISIBLE|WS_CHILD,0,0,0,0,hwnd,(HMENU)(int)(100+IABORT),hInstance,NULL);

               hChild[IUPDATE] = CreateWindow(TEXT("edit"),TEXT(""),WS_CHILD|ES_AUTOHSCROLL|WS_VISIBLE,0,0,0,0,hwnd,(HMENU)(int)(100+IUPDATE),hInstance,NULL);
               wsprintf(szBuffer,TEXT("%d"),iUpdate);
               SetWindowText(hChild[IUPDATE],szBuffer);

               hChild[IPOPUPTIME] = CreateWindow(TEXT("edit"),TEXT(""),WS_CHILD|ES_AUTOHSCROLL|WS_VISIBLE,0,0,0,0,hwnd,(HMENU)(int)(100+IPOPUPTIME),hInstance,NULL);
               wsprintf(szBuffer,TEXT("%d"),iPopupTime);
               SetWindowText(hChild[IPOPUPTIME],szBuffer);
               
               for(i=0; i<(sizeof(hChild)/sizeof(HWND)); i++){
                              SendMessage(hChild[i],WM_SETFONT,(WPARAM)GetStockObject(ANSI_FIXED_FONT),TRUE);
#ifndef NO_SUBCLASS
                              SendMessage(hChild[i],WM_NEWWNDPROC,(WPARAM)hwnd,(LPARAM)SetWindowLong(hChild[i],GWL_WNDPROC,(LONG)TabChildProc));
#endif
               }

               if(!bPopup){
                              SendMessage(hChild[IPOPUP],BM_SETCHECK,BST_UNCHECKED,0);
                              EnableWindow(hChild[IPOPUPTIME],FALSE);
               }
               else
                              SendMessage(hChild[IPOPUP],BM_SETCHECK,BST_CHECKED,0);
               
               if(iTheme == THEME_CIVIL){
                              hBrush = LoadTheme(hwnd,THEME_CIVIL);
                              SendMessage(hChild[ICIVSERV],BM_SETCHECK,BST_CHECKED,0);
                              SendMessage(hChild[IMILSERV],BM_SETCHECK,BST_UNCHECKED,0);
               }
               else{
                              hBrush = LoadTheme(hwnd,THEME_MILITARY);
                              SendMessage(hChild[ICIVSERV],BM_SETCHECK,BST_UNCHECKED,0);
                              SendMessage(hChild[IMILSERV],BM_SETCHECK,BST_CHECKED,0);
               }
               SetFocus(hChild[IOK]);
               return 0;

          case WM_CTLCOLORSTATIC:
          case WM_CTLCOLOREDIT:
               hdc = (HDC)(wParam);
               SetTextColor(hdc,RGB(250,250,250));
               if(iTheme == THEME_MILITARY)
                              SetBkColor(hdc,NATOGREEN);
               else
                              SetBkColor(hdc,LIGHTBLUEBCKGRND);
               return (LRESULT)hBrush;

          case WM_PAINT:
               hdc = BeginPaint(hwnd,&ps);
               SetBkMode(hdc,TRANSPARENT);
               SetTextColor(hdc,RGB(250,250,250));

               SelectObject(hdc,hFont);
               TextOut(hdc,30,iChHeight*2,TEXT("Einstellungen"),13);
               SelectObject(hdc,GetStockObject(ANSI_FIXED_FONT));

               TextOut(hdc,30,iChHeight*6,TEXT("Benutzeroberfl�che anpassen an:"),31);
               TextOut(hdc,30,iChHeight*12,TEXT("Aktualisierungsintervall (in ms):"),33);
               TextOut(hdc,30+iChWidth*22,iChHeight*14,TEXT("(Standard: 1500)"),16);
               TextOut(hdc,30+iChWidth*10,iChHeight*19,TEXT("Anzeigedauer (ms)"),17);

               EndPaint(hwnd,&ps);
               return 0;
          
          case WM_SIZE:
               MoveWindow(hwnd,(int)((GetSystemMetrics(SM_CXSCREEN)-iChWidth*40-70)/2),
                               (int)((GetSystemMetrics(SM_CYSCREEN)-iChHeight*29)/2),
                               70+iChWidth*40,iChHeight*29,TRUE);
                               
               MoveWindow(hGroup,30+iChWidth*9,iChHeight*7,iChWidth*32,iChHeight*4,TRUE);
               
               MoveWindow(hChild[IMILSERV],30+iChWidth*10,iChHeight*8,iChWidth*30,iChHeight,TRUE);
               MoveWindow(hChild[ICIVSERV],30+iChWidth*10,iChHeight*9+3,iChWidth*30,iChHeight,TRUE);
               
               MoveWindow(hChild[IUPDATE],30+iChWidth*10,iChHeight*14,iChWidth*10,iChHeight,TRUE);
               MoveWindow(hChild[IPOPUP],30,iChHeight*17,iChWidth*40,iChHeight,TRUE);
               MoveWindow(hChild[IPOPUPTIME],30+iChWidth*29,iChHeight*19,iChWidth*11,iChHeight,TRUE);
               MoveWindow(hChild[IOK],(int)((iChWidth*40+70)/2-(iChWidth*13)),iChHeight*23,iChWidth*11,iChHeight*2,TRUE);
               MoveWindow(hChild[IABORT],(int)((iChWidth*40+70)/2+(iChWidth*1)),iChHeight*23,iChWidth*12,iChHeight*2,TRUE);
               return 0;
           
          case WM_COMMAND:
               if(HIWORD(wParam) != BN_CLICKED) return 0;
               switch(LOWORD(wParam)-100){
                                 case IMILSERV:
                                      if(SendMessage(hChild[IMILSERV],BM_GETCHECK,0,0) != BST_CHECKED)
                                                                            break;
                                      iTheme = THEME_MILITARY;
                                      DeleteObject(hBrush);
                                      hBrush = LoadTheme(hwnd,iTheme);
                                      InvalidateRect(hwnd,NULL,TRUE);
                                      SendMessage(hParent,WM_THEMECHANGED,iTheme,0);
                                      break;
                                 case ICIVSERV:
                                      if(SendMessage(hChild[ICIVSERV],BM_GETCHECK,0,0) != BST_CHECKED)
                                                                            break;
                                      iTheme = THEME_CIVIL;
                                      DeleteObject(hBrush);
                                      hBrush = LoadTheme(hwnd,iTheme);
                                      InvalidateRect(hwnd,NULL,TRUE);
                                      SendMessage(hParent,WM_THEMECHANGED,iTheme,0);
                                      break;
                                 case IPOPUP:
                                      if(bPopup){
                                             SendMessage(hChild[IPOPUP],BM_SETCHECK,BST_UNCHECKED,0);
                                             EnableWindow(hChild[IPOPUPTIME],FALSE);
                                             bPopup = FALSE;
                                      }
                                      else{
                                             SendMessage(hChild[IPOPUP],BM_SETCHECK,BST_CHECKED,0);
                                             EnableWindow(hChild[IPOPUPTIME],TRUE);
                                             bPopup = TRUE;
                                      }
                                      break;
                                 case IOK:
                                      SaveSettingsTool(iTheme,bPopup,hChild[IUPDATE],hChild[IPOPUPTIME]);
                                      SendMessage(hParent,WM_SETTINGSCHANGED,0,0);
                                      SendMessage(hwnd,WM_CLOSE,0,0);
                                      break;
                                 case IABORT:
                                      SendMessage(hParent,WM_THEMECHANGED,iOldTheme,0);
                                      SendMessage(hwnd,WM_CLOSE,0,0);
                                      break;
               }
               return 0;

          case WM_CHAR:
               if(wParam == VK_TAB)
                              SetFocus(hChild[0]);
               return 0;

          case WM_CHILDTAB:
               for(i=0; (hChild[i]!=(HWND)wParam)&&(i<sizeof(hChild)/sizeof(HWND)); i++)
                              ;
               if((i==IPOPUP) && (!bPopup)) // Popup == FALSE
                              i+=2;
               else
                              i++;
               if(i >= sizeof(hChild)/sizeof(HWND))
                              i = 0;
               SetFocus(hChild[i]);
               return 0;

          case WM_KEYUP:
               if(wParam == VK_F1)
                       return SendMessage(hParent,WM_KEYUP,wParam,lParam);
               break;

          case WM_DESTROY:
               DeleteObject(hFont);
               DeleteObject(hBrush);
               return 0;
     }
     return DefWindowProc(hwnd, message, wParam, lParam);
}


LRESULT CALLBACK WndAboutProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam){
PAINTSTRUCT      ps;
HBITMAP          hbmLogo;
HDC              hdc, hdcLogo;
HGLOBAL          hRes;
HANDLE           hFile;
DWORD            dwWritten;
TEXTMETRIC       tm;
POINTS           pt;
LOGFONT          lf;
static BOOL      bOverLogo;
static HFONT     hFont;
static HWND      hOK;
static HINSTANCE hInstance;
static int       iChWidth, iChHeight;
void*            hResData;

     switch (message){
          case WM_CREATE:
               bOverLogo = FALSE;
               hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);
               hOK = CreateWindow(TEXT("button"),TEXT("OK"),BS_DEFPUSHBUTTON|WS_VISIBLE|WS_CHILD,0,0,0,0,hwnd,(HMENU)(int)100,hInstance,NULL);
               SendMessage(hOK,WM_SETFONT,(WPARAM)GetStockObject(ANSI_FIXED_FONT),TRUE);
               
               hdc = GetDC(hwnd);
               SelectObject(hdc,GetStockObject(ANSI_FIXED_FONT));
               GetTextMetrics(hdc,&tm);
               iChHeight = tm.tmHeight;
               iChWidth = tm.tmMaxCharWidth;

               ZeroMemory(&lf,sizeof(lf));
               lf.lfHeight = -MulDiv(22, GetDeviceCaps(hdc, LOGPIXELSY), 72);
               lf.lfWeight = FW_BOLD;
               lf.lfQuality = ANTIALIASED_QUALITY;
               lf.lfCharSet = tm.tmCharSet;
               lf.lfPitchAndFamily = tm.tmPitchAndFamily;
               lstrcpy(lf.lfFaceName,TEXT("Arial"));
               hFont = CreateFontIndirect(&lf);
               ReleaseDC(hwnd,hdc);
               
               SetFocus(hOK);
               return 0;

          case WM_KEYUP:
               SetFocus(hOK);
               return 0;
          
          case WM_RBUTTONUP:
          case WM_LBUTTONUP:
               if(bOverLogo){
                                 hRes = LoadResource(hInstance,FindResource(hInstance,TEXT("Lw4Wallpaper"),TEXT("BINTYPE")));
                                 hResData = (void*)LockResource(hRes);
                                 hFile = CreateFile(TEXT("Lw4Wallpaper.jpg"),GENERIC_WRITE,FILE_SHARE_WRITE|FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
                                 WriteFile(hFile,hResData,SizeofResource(hInstance,FindResource(hInstance,TEXT("Lw4Wallpaper"),TEXT("BINTYPE"))),&dwWritten,NULL);
                                 CloseHandle(hFile);
                                 FreeResource(hRes);
                                 ShellExecute(hwnd,NULL,TEXT("Lw4Wallpaper.jpg"),NULL,NULL,SW_SHOWNORMAL);
               }    
               return 0;
          
          case WM_MOUSEMOVE:
               pt = MAKEPOINTS(lParam);
               if((pt.x >= iChWidth*27) && (pt.x <= iChWidth*27+80)){ // x
                  if((pt.y >= iChHeight*9+(int)(iChHeight/2)) && (pt.y <= iChHeight*9+(int)(iChHeight/2)+80)){ // y
                                    SetCursor(LoadCursor(NULL,IDC_ARROW));
                                    bOverLogo = TRUE;
                  }
               }
               else{
                              SetCursor(LoadCursor(NULL,IDC_ARROW));
                              bOverLogo = FALSE;
               }    
               return 0;

          case WM_PAINT:
               hdc = BeginPaint(hwnd,&ps);
               
               hbmLogo = LoadBitmap(hInstance,TEXT("Lw4Logo"));
               hdcLogo = CreateCompatibleDC(hdc);
               SelectObject(hdcLogo, hbmLogo);
               BitBlt(hdc,iChWidth*27,iChHeight*9+(int)(iChHeight/2),80,80,hdcLogo,0,0,SRCCOPY);
               DeleteObject(hbmLogo);
               DeleteDC(hdcLogo);
               
               SetBkMode(hdc,TRANSPARENT);
               SetTextColor(hdc,RGB(250,250,250));
               SelectObject(hdc,hFont);
               TextOut(hdc,iChWidth*2,iChHeight+(int)(iChHeight/2),TEXT("StatDZE"),7);
               
               SelectObject(hdc,GetStockObject(ANSI_FIXED_FONT));
               TextOut(hdc,iChWidth*2,iChHeight*5,TEXT("Programmiert von Stefan Partusch"),32);
               /* added by chrham */
               TextOut(hdc,iChWidth*2,iChHeight*5+12,TEXT("NotifyIcon von Chris Hammerschmidt"),34);
               /* end added by chrham */
               TextOut(hdc,iChWidth*2,iChHeight*6+12,TEXT("Copyright (c)2004 Stefan Partusch"),33);
               
               TextOut(hdc,iChWidth*2,iChHeight*10,TEXT("Version:"),8);
                              TextOut(hdc,iChWidth*14,iChHeight*10,STATDZE_VER,lstrlen(STATDZE_VER));
               TextOut(hdc,iChWidth*2,iChHeight*12,TEXT("Build:"),6);
                              TextOut(hdc,iChWidth*14,iChHeight*12,STATDZE_BUILD,lstrlen(STATDZE_BUILD));
               TextOut(hdc,iChWidth*2,iChHeight*14,TEXT("Datum:"),6);
                              TextOut(hdc,iChWidth*14,iChHeight*14,STATDZE_DATE,lstrlen(STATDZE_DATE));
               
               TextOut(hdc,iChWidth*2,iChHeight*18,TEXT("Es gibt keine Garantie auf StatDZE!"),35);
               TextOut(hdc,iChWidth*2,iChHeight*19+2,TEXT("Dieses Programm darf als Freeware"),33);
               TextOut(hdc,iChWidth*2,iChHeight*20+4,TEXT("frei kopiert und verbreitet werden."),35);

               EndPaint(hwnd,&ps);
               return 0;

          case WM_SIZE:
               MoveWindow(hwnd,(int)((GetSystemMetrics(SM_CXSCREEN)-iChWidth*41)/2),
                               (int)((GetSystemMetrics(SM_CYSCREEN)-iChHeight*28+(iChHeight/2))/2),
                               iChWidth*41,(int)(iChHeight*28+(iChHeight/2)),TRUE);
               MoveWindow(hOK,(int)((iChWidth*39-iChWidth*11)/2),iChHeight*23,iChWidth*11,iChHeight*2,TRUE);
               return 0;

          case WM_COMMAND:
               if(LOWORD(wParam) == 100)
                              SendMessage(hwnd,WM_CLOSE,0,0);
               return 0;
           
          case WM_DESTROY:
               DeleteObject(hFont);
               return 0;
     }
     return DefWindowProc(hwnd, message, wParam, lParam);
}
