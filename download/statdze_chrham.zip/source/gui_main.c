////////////////////////////////////////////////////////////////////////////////
//
//          StatDZE    -    www.partusch.de.vu
//          Copyright(c) Stefan Partusch
//
//          Program: StatDZE / Version 1.0.0
//          License: See license.txt (english) or lizenz.txt (deutsch)
//                   Absolutely NO WARRANTY and NO SUPPORT! Use this source at
//                   your very own risk.
//          Date:    2004/06/28
/*
    Anmerkung zu meinen �nderungen (chris hammerschmidt)
    Eigentlich sollte man den Timer ausschalten und bei dem Mousemove-Ereigniss
    des notify-icons die Funktionen zum Berechnen ausrufen sowie die Strings
    korrekt ausschneiden, aber so gings schneller...
*/
#include <windows.h>
/* added by chrham */
#include <shellapi.h>
#include <string.h>
#define WM_NOTIFYICON WM_USER + 0x05
/* end added by chrham */
#include "gui_time.h"
#include "gui_functions.h"
#include "gui_tabchildproc.h"
#include "gui_toolwindows.h"
#include "gui_main.h"

BOOL tray;
NOTIFYICONDATA info;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,PSTR szCmdLine, int iCmdShow){
     HWND         hwnd;
     MSG          msg;
     WNDCLASS     wndclass;
      
     wndclass.style         = CS_HREDRAW | CS_VREDRAW;
     wndclass.cbClsExtra    = 0;
     wndclass.cbWndExtra    = 0;
     wndclass.hInstance     = hInstance;
     wndclass.hIcon         = LoadIcon (hInstance, TEXT("A"));
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
     wndclass.hbrBackground = (HBRUSH)GetStockObject(LTGRAY_BRUSH);
     
     if(lstrcmpi(szCmdLine,TEXT("-autostart"))){
         wndclass.lpfnWndProc   = WndProc;
         wndclass.lpszMenuName  = TEXT("STATDZEMENU");
         wndclass.lpszClassName = TEXT("StatDZE100_Main");
         if (!RegisterClass(&wndclass)){return 0;}
         hwnd = CreateWindow(wndclass.lpszClassName, TEXT("StatDZE - Wie lange noch?"),
                          WS_OVERLAPPED | WS_SYSMENU | WS_VISIBLE | WS_MINIMIZEBOX,
                          0,0,0,0,NULL,NULL, hInstance, NULL);
     }
     else{
          wndclass.lpfnWndProc   = WndProcAutostart;
          wndclass.lpszMenuName  = NULL;
          wndclass.lpszClassName = TEXT("StatDZE100_Autostart");
          if (!RegisterClass(&wndclass)){return 0;}
          hwnd = CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, wndclass.lpszClassName, TEXT("StatDZE"),
                          WS_VISIBLE | WS_POPUP,
                          0,0,0,0,NULL,NULL,hInstance,NULL);
     }

     /* added by chrham */
     info.cbSize = sizeof(NOTIFYICONDATA); 
     info.hWnd = hwnd; 
     info.uID = 1; 
     strcpy(info.szTip, "test123");
     info.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP; 
     info.uCallbackMessage = WM_NOTIFYICON; 
     info.hIcon =
        (HICON)LoadImage( hInstance, "C:\\Programme\\StatDZE\\source\\StatDZE.ico",
            IMAGE_ICON, 0, 0, LR_DEFAULTSIZE | LR_LOADFROMFILE);
     /* end added by chrham */

     ShowWindow(hwnd, iCmdShow);
     UpdateWindow(hwnd);
     while(GetMessage(&msg, NULL, 0, 0)){
          TranslateMessage(&msg);
          DispatchMessage(&msg);
     }
     return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam){
PAINTSTRUCT      ps;
HDC              hdc;
TEXTMETRIC       tm;
TCHAR            szBuffer[128];
static TCHAR     szCurrentDate[128];
static RECT      rectTime;
static BOOL      bShowMsg, bUpdateMsg;
static HWND      hDZB, hDZE, hOut, hVacation, hHolidayLegal;
static HBRUSH    hBrush;
static HINSTANCE hInstance;
static POINT     ptPos;
static int       iTheme, iUpdate, iChHeight, iChWidth;

     switch (message){
          case WM_CREATE:
               hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);
               hDZB = CreateWindow(TEXT("edit"),TEXT(""),WS_CHILD|ES_AUTOHSCROLL|WS_VISIBLE, 0,0,0,0, hwnd,(HMENU)5010, hInstance, 0);
               hDZE = CreateWindow(TEXT("edit"),TEXT(""),WS_CHILD|ES_AUTOHSCROLL|WS_VISIBLE, 0,0,0,0, hwnd,(HMENU)5020, hInstance, 0);
               hVacation = CreateWindow(TEXT("edit"),TEXT(""),WS_CHILD|ES_AUTOHSCROLL|WS_VISIBLE, 0,0,0,0, hwnd,(HMENU)5030, hInstance, 0);
               hHolidayLegal = CreateWindow(TEXT("edit"),TEXT(""),WS_CHILD|ES_AUTOHSCROLL|WS_VISIBLE, 0,0,0,0, hwnd,(HMENU)5040, hInstance, 0);
               hOut = CreateWindow(TEXT("edit"),TEXT(""),WS_CHILD|ES_MULTILINE|ES_READONLY|ES_WANTRETURN|ES_AUTOVSCROLL|WS_VISIBLE, 0,0,0,0, hwnd,(HMENU)5050, hInstance, 0);

               SendMessage(hDZB,WM_SETFONT,(WPARAM)GetStockObject(ANSI_FIXED_FONT),TRUE);
               SendMessage(hDZE,WM_SETFONT,(WPARAM)GetStockObject(ANSI_FIXED_FONT),TRUE);
               SendMessage(hOut,WM_SETFONT,(WPARAM)GetStockObject(ANSI_FIXED_FONT),TRUE);
               SendMessage(hVacation,WM_SETFONT,(WPARAM)GetStockObject(ANSI_FIXED_FONT),TRUE);
               SendMessage(hHolidayLegal,WM_SETFONT,(WPARAM)GetStockObject(ANSI_FIXED_FONT),TRUE);
#ifndef NO_SUBCLASS               
               SendMessage(hDZB,WM_NEWWNDPROC,(WPARAM)hwnd,(LPARAM)SetWindowLong(hDZB,GWL_WNDPROC,(LONG)TabChildProc));
               SendMessage(hDZE,WM_NEWWNDPROC,(WPARAM)hwnd,(LPARAM)SetWindowLong(hDZE,GWL_WNDPROC,(LONG)TabChildProc));
               SendMessage(hOut,WM_NEWWNDPROC,(WPARAM)hwnd,(LPARAM)SetWindowLong(hOut,GWL_WNDPROC,(LONG)TabChildProc));
               SendMessage(hVacation,WM_NEWWNDPROC,(WPARAM)hwnd,(LPARAM)SetWindowLong(hVacation,GWL_WNDPROC,(LONG)TabChildProc));
               SendMessage(hHolidayLegal,WM_NEWWNDPROC,(WPARAM)hwnd,(LPARAM)SetWindowLong(hHolidayLegal,GWL_WNDPROC,(LONG)TabChildProc));
#endif
               hdc = GetDC(hwnd);
               SelectObject(hdc,GetStockObject(ANSI_FIXED_FONT));
               GetTextMetrics(hdc,&tm);
               iChHeight = tm.tmHeight;
               iChWidth = tm.tmMaxCharWidth;
               ReleaseDC(hwnd,hdc);

               switch(GetSettings(&iTheme,&iUpdate,NULL,NULL,&ptPos,hDZB,hDZE,hVacation,hHolidayLegal)){
                              case FIRST_START:
                                   //MessageBox(hwnd,TEXT("Dies ist eine BETA-Version und nicht die endg�ltige Version!\nDie finale Version von StatDZE 1.0.0 wird in K�rze erscheinen!"),TEXT("StatDZE - BETA-Version"),MB_OK|MB_ICONINFORMATION);
                                   CreateToolWindow(hwnd,TEXT("StatDZE - Einstellungen"),WndSettingsProc);
                              case NEEDGREETING_START:
                                   bShowMsg = FALSE;
                                   SetWindowText(hOut,TEXT("StatDZE - www.partusch.de.vu\r\n\r\nBitte trage jetzt dein DZB und DZE ein.\r\nF�r Hilfe einfach entweder F1 dr�cken oder auf \"Hilfe/Programmhilfe �ffnen\" klicken!"));
                                   break;
                              case NORMAL_START:
                              default:
                                   bShowMsg = TRUE;
                                   ShowOutputMessage(hOut,hDZB,hDZE,hVacation,hHolidayLegal);
                                   break;
               }

               GetCurrentDateString(iTheme,szCurrentDate,MAX_CHARS(szCurrentDate));
               bUpdateMsg = FALSE;
               
               hBrush = LoadTheme(hwnd,iTheme);
               SetTimer(hwnd,1,iUpdate,NULL);
               return 0;

          case WM_TIMER:
               GetCurrentDateString(iTheme,szBuffer,MAX_CHARS(szBuffer));
               if(lstrcmpi(szBuffer,szCurrentDate)){
                     lstrcpy(szCurrentDate,szBuffer);
                     InvalidateRect(hwnd,&rectTime,TRUE);
                     bUpdateMsg = TRUE;
               }
               if(bUpdateMsg && bShowMsg){
                     ShowOutputMessage(hOut,hDZB,hDZE,hVacation,hHolidayLegal);
                     bUpdateMsg = FALSE;
               }
               return 0;

          case WM_CTLCOLOREDIT:
          case WM_CTLCOLORSTATIC:
               hdc = (HDC)(wParam);
               SetTextColor(hdc,RGB(250,250,250));
               if(iTheme == THEME_MILITARY)
                              SetBkColor(hdc,NATOGREEN);
               else
                              SetBkColor(hdc,LIGHTBLUEBCKGRND);
               return (LRESULT)hBrush;
          
          case WM_THEMECHANGED:
               iTheme = (int)(wParam);
               DeleteObject(hBrush);
               hBrush = LoadTheme(hwnd,iTheme);
               InvalidateRect(hwnd,NULL,TRUE);
               return 0;

          case WM_SETTINGSCHANGED:
               GetSettings(NULL,&iUpdate,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
               KillTimer(hwnd,1);
               SetTimer(hwnd,1,iUpdate,NULL);
               return 0;
     
          case WM_PAINT:
               hdc = BeginPaint(hwnd,&ps);
               SetBkMode(hdc,TRANSPARENT);
               SetTextColor(hdc,RGB(250,250,250));
               SelectObject(hdc,GetStockObject(ANSI_FIXED_FONT));
               
               rectTime.left = iChWidth*31; //x
               rectTime.top = iChHeight*6; //y
               rectTime.right = iChWidth*(31+22); //x
               rectTime.bottom = iChHeight*7; //y

               TextOut(hdc,iChWidth*3,iChHeight*2,TEXT("DienstZeitBeginn:"),17);
               TextOut(hdc,iChWidth*3,iChHeight*4,TEXT("DienstZeitEnde:"),15);
               
               TextOut(hdc,iChWidth*3,iChHeight*6,TEXT("Aktuelle Zeit:"),14);
               TextOut(hdc,iChWidth*31,iChHeight*6,szCurrentDate,lstrlen(szCurrentDate));
               
               TextOut(hdc,iChWidth*3,iChHeight*19,TEXT("Restlicher Urlaub:"),18);
               TextOut(hdc,iChWidth*3,iChHeight*21,TEXT("Restliche Feiertage:"),20);

               EndPaint(hwnd,&ps);
               return 0;

          /* added by chrham */
          case WM_NOTIFYICON:
                    if(lParam == WM_LBUTTONDOWN) {
                         Shell_NotifyIcon(NIM_DELETE, &info);
                         ShowWindow(hwnd,SW_SHOW);
                         ShowWindow(hwnd,SW_RESTORE);
                    }
                    else if(lParam == WM_MOUSEMOVE) {
                         GetWindowText(hOut,info.szTip, 120);
                         Shell_NotifyIcon(NIM_MODIFY,&info);
                    }
               return 0;
          /* end added by chrham */

          case WM_SIZE:
               /* added by chrham */
               if(wParam == SIZE_MINIMIZED) {
                   Shell_NotifyIcon(NIM_ADD, &info);
                   ShowWindow(hwnd, SW_HIDE);
                   tray = TRUE;
               }
               /* end added by chrham */
               if((ptPos.x == -100) && (ptPos.y == -100))
                    MoveWindow(hwnd,(int)((GetSystemMetrics(SM_CXSCREEN)-iChWidth*57)/2),
                                    (int)((GetSystemMetrics(SM_CYSCREEN)-iChHeight*28)/2),
                                    iChWidth*57,iChHeight*28,TRUE);
               else
                    MoveWindow(hwnd,ptPos.x,ptPos.y,iChWidth*57,iChHeight*28,TRUE);
               MoveWindow(hDZB,iChWidth*31,iChHeight*2,
                               iChWidth*22,iChHeight,FALSE);
               MoveWindow(hDZE,iChWidth*31,iChHeight*4,
                               iChWidth*22,iChHeight,FALSE);
               MoveWindow(hOut,iChWidth*4,iChHeight*9,
                               iChWidth*48,iChHeight*8,FALSE);
               MoveWindow(hVacation,iChWidth*31,iChHeight*19,
                               iChWidth*22,iChHeight,FALSE);
               MoveWindow(hHolidayLegal,iChWidth*31,iChHeight*21,
                               iChWidth*22,iChHeight,FALSE);
               return 0;
           
          case WM_COMMAND:
               switch(LOWORD(wParam)){
                                 case 101:
                                      CreateToolWindow(hwnd,TEXT("StatDZE - Einstellungen"),WndSettingsProc);
                                      break;
                                 case 102:
                                      SendMessage(hwnd,WM_CLOSE,0,0);
                                      break;
                                 case 201:
                                      CreateToolWindow(hwnd,TEXT("�ber StatDZE..."),WndAboutProc);
                                      //MessageBox(hwnd,TEXT("HappyDZE Version 1.0\nProgrammiert von Stefan Partusch\nwww.partusch.de.vu\n\nCopyright (c)2004 Stefan Partusch"),TEXT("�ber HappyDZE"), MB_OK | MB_ICONINFORMATION);
                                      break;
                                 case 202:
                                      SendMessage(hwnd,WM_KEYUP,VK_F1,0);
                                      //ShellExecute(NULL,NULL,TEXT("hilfe.html"),NULL,NULL,SW_SHOWNORMAL);
                                      break;
                                 case 203:
                                      ShellExecute(hwnd,NULL,TEXT("http://www.partusch.de.vu"),NULL,NULL,SW_SHOWNORMAL);
                                      break;
                                 case 5010:
                                 case 5020:
                                      if(HIWORD(wParam) == EN_SETFOCUS){
                                          GetWindowText((HWND)lParam,szBuffer,MAX_CHARS(szBuffer));
                                          if(!lstrcmp(szBuffer,TEXT("Hier DZB eintragen")) || !lstrcmp(szBuffer,TEXT("Hier DZE eintragen")))
                                                             SetWindowText((HWND)lParam,TEXT(""));
                                          break;
                                      }
                                 case 5030:
                                 case 5040:
                                      if(HIWORD(wParam) == EN_CHANGE){
                                              bShowMsg = TRUE;
                                              bUpdateMsg = TRUE;
                                      }
                                      break;
               }
               return 0;
          
          case WM_CHAR:
               if(wParam == VK_TAB)
                              SetFocus(hDZB);
               return 0;
          
          case WM_CHILDTAB:
               if((HWND)wParam == hDZB)
                              SetFocus(hDZE);
               else if((HWND)wParam == hDZE)
                              SetFocus(hVacation);
               else if((HWND)wParam == hVacation)
                              SetFocus(hHolidayLegal);
               else if((HWND)wParam == hHolidayLegal || (HWND)wParam == hOut)
                              SetFocus(hDZB);
               return 0;
          
          case WM_KEYUP:
               if(wParam == VK_F1){
                       if((int)ShellExecute(hwnd,NULL,TEXT("Hilfe.html"),NULL,NULL,SW_SHOWNORMAL) <= 32)
                                              MessageBox(hwnd,TEXT("Die Hilfedatei konnte nicht aufgerufen werden!"),TEXT("StatDZE - Fehler"), MB_OK|MB_ICONERROR);
                       return 0;
               }
               break;

          case WM_DESTROY:
               /* added by chrham */
               Shell_NotifyIcon(NIM_DELETE,&info);
               /* end added by chrham */
               KillTimer(hwnd,1);
               SaveSettingsMain(hwnd,hDZB,hDZE,hVacation,hHolidayLegal);
               DeleteObject(hBrush);
               PostQuitMessage(0);
               return 0;
     }
     return DefWindowProc(hwnd, message, wParam, lParam);
}


LRESULT CALLBACK WndProcAutostart(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam){
PAINTSTRUCT      ps;
HDC              hdc;
TEXTMETRIC       tm;
HRGN             hRgn;
int              iLen, iLineOld;
static int       iTheme, iUpdate, iPopupTime, iChHeight, iChWidth, iLine1, iLine2;
static TCHAR     szMessage[256];
static HBRUSH    hBrush;
static HINSTANCE hInstance;
static _TIME     _tDZE, _tHoliday;

     switch (message){
          case WM_CREATE:
               hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);
               GetSettings(&iTheme,&iUpdate,&iPopupTime,NULL,NULL,NULL,NULL,NULL,NULL);
               GetSettingsTime(&_tDZE,&_tHoliday);
               hBrush = LoadTheme(hwnd,iTheme);
               iLine1 = 0;
               iLine2 = 0;

               hdc = GetDC(hwnd);
               SelectObject(hdc,GetStockObject(ANSI_FIXED_FONT));
               GetTextMetrics(hdc,&tm);
               iChHeight = tm.tmHeight;
               iChWidth = tm.tmMaxCharWidth;
               ReleaseDC(hwnd,hdc);

               SendMessage(hwnd,WM_TIMER,1,0);
               SetTimer(hwnd,1,iUpdate,NULL);
               SetTimer(hwnd,2,iPopupTime,NULL);
               return 0;

          case WM_KEYUP:
          case WM_RBUTTONUP:
          case WM_LBUTTONUP:
               SendMessage(hwnd,WM_CLOSE,0,0);
               return 0;

          case WM_TIMER:
               if(wParam == 1){
                         GetAutostartMessage(szMessage,MAX_CHARS(szMessage),_tDZE,_tHoliday);
                         iLen = lstrlen(szMessage);
                         iLineOld = iLine1;
                         iLine1 = (int)((float)(lstrlen(szMessage))/2);
                         for(; iLine1<iLen && szMessage[iLine1]!=TEXT(' '); iLine1++) ; // search next space
                         iLine2 = iLen - iLine1 - 1;
                         if(iLine1 != iLineOld)
                                SendMessage(hwnd,WM_SIZE,0,0);
                         InvalidateRect(hwnd,NULL,TRUE);
               }
               else
                         SendMessage(hwnd,WM_CLOSE,0,0);
               return 0;
     
          case WM_PAINT:
               hdc = BeginPaint(hwnd,&ps);
               SetBkMode(hdc,TRANSPARENT);
               SetTextColor(hdc,RGB(250,250,250));
               SelectObject(hdc,GetStockObject(ANSI_FIXED_FONT));

               TextOut(hdc,iChWidth*6,iChHeight*2-2,szMessage,iLine1);
               TextOut(hdc,iChWidth*6,iChHeight*3+2,szMessage+iLine1+1,iLine2);

               EndPaint(hwnd,&ps);
               return 0;

          case WM_SIZE:
               MoveWindow(hwnd,(int)((GetSystemMetrics(SM_CXSCREEN)-iChWidth*(iLine1+14))/2),
                               (int)((GetSystemMetrics(SM_CYSCREEN)-iChHeight*6)/2),
                               iChWidth*(iLine1+14),iChHeight*6,TRUE);
               hRgn = CreateRoundRectRgn(0,0,iChWidth*(iLine1+14),iChHeight*6,3*iChWidth,3*iChWidth);
               SetWindowRgn(hwnd,hRgn,TRUE);
               return 0;

          case WM_DESTROY:
               KillTimer(hwnd,1);
               KillTimer(hwnd,2);
               DeleteObject(hBrush);
               PostQuitMessage(0);
               return 0;
     }
     return DefWindowProc(hwnd, message, wParam, lParam);
}
