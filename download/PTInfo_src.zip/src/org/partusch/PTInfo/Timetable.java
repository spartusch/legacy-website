/*
* Timetable.java	Version 0.0.1		2005/10/25
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

import java.util.Date;
import java.util.Calendar;

/**
 * Provides access to timetable related data of a public transportation line.
 * @version 0.0.1 25 OCT 2005
 * @author Stefan Partusch
 */
public class Timetable {
	private String times[];

	/** Constructor given the timetable data of a public transportation line.
	* @param rawData	Timetable data */
	public Timetable(String rawData) throws CorruptedDataException {
		String s[] = new ExString(rawData).strip().split(';');
		
		if((s.length < 2) || (s.length%2 != 0))
			throw new CorruptedDataException("Invalid timetable data");

		times = new String[24];

		try {
			for(int i=0; i<s.length; i+=2) {
				int hour = Integer.parseInt(s[i]);
				if(hour < 0 || hour > 23)
					throw new CorruptedDataException("Invalid timetable data");
				times[hour] = s[i+1];
			}
		}
		catch(NumberFormatException e) {
			throw new CorruptedDataException(e.getMessage());
		}
	}

	/** Finds the next available connection after or at the given time.
	* @param time	The time to start looking for connections for in milliseconds since 1 JAN 1970, 0:00 GMT
	* @return		 {@link javax.microedition.lcdui.Date Date} of the next available connection. */
	public Date getNextConnection(long time) throws CorruptedDataException {
		Calendar c = Calendar.getInstance();
		Calendar cNew = Calendar.getInstance();

		c.setTime(new Date(time));

		cNew.set(Calendar.HOUR_OF_DAY, c.get(Calendar.HOUR_OF_DAY));
		cNew.set(Calendar.MINUTE, 0);
		cNew.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH));
		cNew.set(Calendar.MONTH, c.get(Calendar.MONTH));
		cNew.set(Calendar.YEAR, c.get(Calendar.YEAR));

		do { // loop hours
			int curHour = cNew.get(Calendar.HOUR_OF_DAY);
			
			if(times[curHour] != null) {
				String[] minutes = new ExString(times[curHour]).split(',');

				try {
					for(int i=0; i<minutes.length; i++) { // loop minutes
						String minFlags[] = new ExString(minutes[i]).split('+');
						int curMin = Integer.parseInt(minFlags[0]);
					
						if( (  (curHour == c.get(Calendar.HOUR_OF_DAY)) && (curMin >= c.get(Calendar.MINUTE))  )
							|| (curHour != c.get(Calendar.HOUR_OF_DAY)) )
						{
							if(connectionOk(cNew.get(Calendar.DAY_OF_MONTH),
								cNew.get(Calendar.MONTH), cNew.get(Calendar.DAY_OF_WEEK),
								curHour, curMin, minFlags))
							{
								cNew.set(Calendar.MINUTE,curMin);
								return cNew.getTime();
							}
						}
					}
				}
				catch(NumberFormatException e) {
					throw new CorruptedDataException(e.getMessage());
				}
			}

			// no minute found for this hour
			long newTime = cNew.getTime().getTime()+1*60*60*1000+1; // add one hour
			cNew = Calendar.getInstance();
			cNew.setTime(new Date(newTime));

		} while(cNew.get(Calendar.HOUR_OF_DAY) != c.get(Calendar.HOUR_OF_DAY));
        
		return c.getTime();
	}

	/** Simply checks whether the given connection is available.
	* @param day			The day of the connection
	* @param month		The month of the connection
	* @param dow			The day of the week of the connection
	* @param hour		Hour of the connection
	* @param min			Minute of the connection
	* @param flags		Timetable data for that connection
	* @return			true if it's ok, false otherwise. */
	private boolean connectionOk(int day, int month, int dow, int hour, int min, String flags[]) throws CorruptedDataException {
		month += 1; // e.g. January: 0 to 1
		
		if(month == 12 && (day == 24 || day == 31))
			dow = Calendar.SATURDAY;
		
		boolean onlyWeekday = false, onlyWeekend = false;
		
		try {
			for(int i=1; i<flags.length; i++) { // i=1 because flags[0] is the minute in question
				switch(flags[i].charAt(0)) {
					case 'w': // monday to friday
						onlyWeekday = true;
						break;
					case 's': // saturday and sunday
						onlyWeekend = true;
						break;
					case 'f': // only(!) nights friday/saturday, saturday/sunday
						switch(dow) {
							case Calendar.FRIDAY:
								if(hour < 18)
									return false;
								break;
							case Calendar.SATURDAY:
								if((hour > 8) && (hour < 18))
									return false;
								break;
							case Calendar.SUNDAY:
								if(hour > 8)
									return false;
								break;
							default:
								return false;
						}
						return true;
					case 'd': // dX: only on weekday X
						if(dow != Integer.parseInt(flags[i].substring(1)))
							return false;
						break;
					case 'n': // nX: not on weekday X
						if(dow == Integer.parseInt(flags[i].substring(1)))
							return false;
						break;
					case 'o': // oDDMM: only on day.month.
						if( ( day != Integer.parseInt(flags[i].substring(1,3)) )
							|| ( month != Integer.parseInt(flags[i].substring(3)) ) )
								return false;
						break;
					case 'c': // cDDMM: not on day.month.
						if( ( day == Integer.parseInt(flags[i].substring(1,3)) )
							&& ( month == Integer.parseInt(flags[i].substring(3)) ) )
								return false;
						break;
					case 'z': { // zDDMMDDMM: only between day.month and day.month.
						//          0 12 34 56 78
							int sMonth = Integer.parseInt(flags[i].substring(3,5));
							int eMonth = Integer.parseInt(flags[i].substring(7));
							if((month < sMonth) || (month > eMonth))
								return false;
							int sDay = Integer.parseInt(flags[i].substring(1,3));
							int eDay = Integer.parseInt(flags[i].substring(5,7));
							if((month == sMonth) && (day < sDay))
								return false;
							else if((month == eMonth) && (day > eDay))
								return false;
						}
						break;
					default:
						throw new CorruptedDataException("Invalid flag");
				}
			}
		}
		catch(NumberFormatException e) { throw new CorruptedDataException("Invalid entry"); }
		catch(IndexOutOfBoundsException e) { throw new CorruptedDataException("Invalid flag"); }

		if(onlyWeekday && !onlyWeekend && (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY))
			return false;
		if(onlyWeekend && !onlyWeekday && (dow != Calendar.SATURDAY && dow != Calendar.SUNDAY))
			return false;
		
		return true;
	}
}
