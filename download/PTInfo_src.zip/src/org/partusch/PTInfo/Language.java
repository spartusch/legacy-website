/*
* Language.java	Version 0.0.1		2005/10/20
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

/**
 * Internationalisation class. Manages all language dependent strings.
 * @version 0.0.1 20 OCT 2005
 * @author Stefan Partusch
 */
public class Language {
	/** Commands, others ... */
	public static final int	OK = 1;
	public static final int	LOAD = 2;
	public static final int	SAVE = 3;
	public static final int	BACK = 4;
	public static final int	QUIT = 5;
	public static final int	HELP_FILE = 6;
	/** Menu strings. M = Menu; L = Long; S = Short; */
	/* Short */
	public static final int	M_FAVORITES_S = 7;
	public static final int	M_DESTINATION_S = 8;
	public static final int	M_START_S = 9;
	public static final int	M_RETURN_S = 10;
	public static final int	M_TIME_S = 11;
	public static final int	M_LINE_S = 12;
	public static final int	M_LANG_S = 13;
	public static final int	M_HELP_S = 14;
	public static final int	M_URL_S = 15;
	public static final int	M_ABOUT_S = 16;
	/* Long */
	public static final int	M_FAVORITES_L = 17;
	public static final int	M_DESTINATION_L = 18;
	public static final int	M_START_L = 19;
	public static final int	M_RETURN_L = 20;
	public static final int	M_TIME_L = 21;
	public static final int	M_LINE_L = 22;
	public static final int	M_LANG_L = 23;
	public static final int	M_HELP_L = 24;
	public static final int	M_URL_L = 25;
	public static final int	M_ABOUT_L = 26;
	/** String items */
	public static final int	START = 27;
	public static final int	DESTINATION = 28;
	public static final int	DEPARTURES_AT = 29;
	public static final int	CONNECTION1 = 30;
	public static final int	CONNECTION2 = 31;
	public static final int	DEPARTURE = 32;
	public static final int	ARRIVAL = 33;
	public static final int	OCLOCK = 34;
	public static final int	IN_HOURS = 35;
	public static final int	NOW = 36;
	public static final int	FROM = 37;
	public static final int	TO = 38;
	public static final int	WAIT = 39;

	private static final int LAST_ID_USED = 39;
	
	private String lang[];
	
	/** @param fileData		Data to extract the language strings from. */
	public Language(String fileData) throws CorruptedDataException {
		ExString data = new ExString(fileData).stripAsciiControls(); // necessary because trim() doesn't remove line breaks on some devices
		lang = data.split(';');
		if(lang.length != LAST_ID_USED)
			throw new CorruptedDataException("Invalid language file");
	}
	
	/** Checks whether an ID is valid. */
	private boolean isValid(int id) {
		if((id > 0) && (id <= LAST_ID_USED))
			return true;
		return false;
	}
	
	/** Retrieves a language string from an ID.
	* @param id	The ID
	* @return	The language string or null. */
	public String get(int id) {
		if(!isValid(id))
			return null;
		return lang[id-1];
	}
	
	/** Finds an ID to a given language string.
	* @param langStr	The language string
	* @return 		The ID or -1. */
	public int getID(String langStr) {
		for(int i=0; i<lang.length; i++) {
			if(lang[i].equals(langStr))
				return i+1;
		}
		return -1;
	}
}
