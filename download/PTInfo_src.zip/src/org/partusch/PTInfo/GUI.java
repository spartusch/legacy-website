/*
* GUI.java	Version 0.0.1		2005/10/25
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

import java.io.IOException;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.Screen;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.Spacer;

/**
 * Creates and maintains all  {@link javax.microedition.lcdui.Screen Screens} , i.e. everything that is displayed.
 * @version 0.0.1 25 OCT 2005
 * @author Stefan Partusch
 */
public class GUI {
	/** The version of PTInfo. */
	private static final String VERSION = "0.0.1";

	/* Screens */
	/** Constant refering to the splash {@link javax.microedition.lcdui.Screen Screen}. */
	public static final int SPLASH = 0;
	/** The main {@link javax.microedition.lcdui.Screen Screen}. */
	public static final int MAIN = 1;
	/** {@link javax.microedition.lcdui.Screen Screen} for the language selection. */
	public static final int SEL_LANG = 2;
	/** {@link javax.microedition.lcdui.Screen Screen} for the selection of the desired line. */
	public static final int SEL_LINE = 3;
	/** {@link javax.microedition.lcdui.Screen Screen} for the selection of the starting station. */
	public static final int SEL_START = 4;
	/** {@link javax.microedition.lcdui.Screen Screen} for the selection of the destination. */
	public static final int SEL_DEST = 5;
	/** {@link javax.microedition.lcdui.Screen Screen} for the selection of the time delay. */
	public static final int SEL_TIME = 6;
	/** The about {@link javax.microedition.lcdui.Screen Screen}. */
	public static final int ABOUT = 7;
	/** The help {@link javax.microedition.lcdui.Screen Screen}. */
	public static final int HELP = 8;
	/** {@link javax.microedition.lcdui.Screen Screen} to manage the favorites. */
	public static final int FAVORITES = 9;
	/** "Please wait" {@link javax.microedition.lcdui.Screen Screen}. */
	public static final int WAIT = 10;

	/** The biggest ID used for screens.
	* @see #validID(int) */
	private static final int LAST_SCREEN_ID = 10;

	/* Commands - {@link javax.microedition.lcdui.Screen Screens} */
	/** ID of the command for the selection of the language. */
	public static final int CMD_LANG = 0;
	/** Command for the selection of the line. */
	public static final int CMD_LINE = 1;
	/** Command for the selection of the starting station. */
	public static final int CMD_START = 2;
	/** Command for the selection of the destination station. */
	public static final int CMD_DEST = 3;
	/** Command to change the time offset. */
	public static final int CMD_TIME = 4;
	/** Command to display help. */
	public static final int CMD_HELP = 5;
	/** Command to display the about screen. */
	public static final int CMD_ABOUT = 6;
	/** Command to display management of the favorites. */
	public static final int CMD_FAVORITES = 7;

	/* Commands - actions */
	/** Command to accept the GPL. */
	public static final int CMD_ACCEPT = 8;
	/** Command for the conformation of lists. */
	public static final int CMD_OK = 9;
	/** Command to load a selected favorite */
	public static final int CMD_LOAD = 10;
	/** Command to save current data as a favorite */
	public static final int CMD_SAVE = 11;
	/** Command to return to main screen */
	public static final int CMD_BACK = 12;
	/** Command to change the direction. */
	public static final int CMD_RETURN = 13;
	/** Command to load www.partusch.de.vu. */
	public static final int CMD_URL = 14;
	/** Command to quit the application. */
	public static final int CMD_QUIT = 15;

	private int				curUI;
	private Screen			uis[];
	private Language		lang;
	private CommandListener	parent;

	/** Constructor given a {@link javax.microedition.lcdui.CommandListener CommandListener} and language strings.
	* @param listener		{@link javax.microedition.lcdui.CommandListener CommandListener}
	* @param language		Language strings to be used */
	public GUI(CommandListener listener, Language language) {
		uis = new Screen[LAST_SCREEN_ID+1];
		curUI = -1;
		parent = listener;
		lang = language;
	}

	/** Gets a {@link javax.microedition.lcdui.Command command}'s ID from its label.
	* @param label	Short label of the {@link javax.microedition.lcdui.Command command}
	* @return 		Returns the command's ID if found, -1 otherwise. */
	public int getCommandID(String label) {
		if(lang == null) {
			if(label.equals("Ok"))
				return CMD_OK;
			else if(label.equals("Accept"))
				return CMD_ACCEPT;
			else if(label.equals("Partusch.de.vu"))
				return CMD_URL;
			else if(label.equals("Exit"))
				return CMD_QUIT;
		}
		else {
			switch(lang.getID(label)) {
				case Language.OK:
					return CMD_OK;
				case Language.LOAD:
					return CMD_LOAD;
				case Language.SAVE:
					return CMD_SAVE;
				case Language.BACK:
					return CMD_BACK;
				case Language.QUIT:
					return CMD_QUIT;

				case Language.M_FAVORITES_S:
					return CMD_FAVORITES;
				case Language.M_DESTINATION_S:
					return CMD_DEST;
				case Language.M_START_S:
					return CMD_START;
				case Language.M_RETURN_S:
					return CMD_RETURN;
				case Language.M_TIME_S:
					return CMD_TIME;
				case Language.M_LINE_S:
					return CMD_LINE;
				case Language.M_LANG_S:
					return CMD_LANG;
				case Language.M_HELP_S:
					return CMD_HELP;
				case Language.M_URL_S:
					return CMD_URL;
				case Language.M_ABOUT_S:
					return CMD_ABOUT;
			}
		}
		return -1;
	}

	/** Checks wether the parameter is a valid referral to a {@link javax.microedition.lcdui.Screen Screen}.
	* @param id	The value to be checked
	* @return 	Returns true if id is valid, false otherwise */
	private boolean validID(int id) {
		if( (lang == null) && (id == GUI.SPLASH || id == GUI.SEL_LANG) )
			return true;
		else if( (lang != null) && (id >= 0 && id <= GUI.LAST_SCREEN_ID) )
			return true;
		System.err.println("GUI:Invalid ID");
		return false;
	}

	/** Sets the title of a {@link javax.microedition.lcdui.Screen Screen}.
	* @param id		{@link javax.microedition.lcdui.Screen Screen} of which to change the title
	* @param title	New title */
	public void setTitle(int id, String title) {
		if(validID(id)) {
			try { getScreen(id).setTitle(title); }
			catch(IOException e) { e.printStackTrace(); }
		}
	}

	/** Sets the current {@link javax.microedition.lcdui.Screen Screen}.
	* @param id	Referral to the {@link javax.microedition.lcdui.Screen Screen} to set
	* @return 	Returns the old screen's ID or -1. */
	public int setCurrentScreen(int id) {
		if(!validID(id))
			return -1;
		int old = curUI;
		curUI = id;
		return old;
	}

	/** Returns the current {@link javax.microedition.lcdui.Screen Screen's} ID.
	* @return 	ID of the {@link javax.microedition.lcdui.Screen Screen} currently set. */
	public int getCurrentScreenID() { return curUI; }

	/** Returns the current {@link javax.microedition.lcdui.Screen Screen}.
	* @return 	The {@link javax.microedition.lcdui.Screen Screen} currently set. */
	public Screen getCurrentScreen() throws IOException { return getScreen(curUI); }

	private Screen getScreen(int id) throws IOException {
		if(uis[id] == null)
			uis[id] = createScreen(id);
		return uis[id];
	}
	private Screen createScreen(int id) throws IOException {
		switch(id) {
			case GUI.ABOUT:
			case GUI.SPLASH: {
				Form f;
				if(id == GUI.SPLASH)
					f = new Form("PTInfo Munich");
				else
					f = new Form(lang.get(Language.M_ABOUT_L));
				f.append("PTInfo Munich for Mobiles " + VERSION + "\nby Stefan Partusch\nhttp://www.partusch.de.vu\n\n" +
					"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; " +
					"without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n" +
					"See the GNU General Public License for more details. It is available at http://www.partusch.de.vu, " +
					"the homepage of PTInfo.");
				if(id == GUI.SPLASH) {
					f.addCommand(new Command("Accept", Command.ITEM, 1));
					f.addCommand(new Command("Partusch.de.vu", "Visit partusch.de.vu", Command.ITEM, 2));
					f.addCommand(new Command("Exit", Command.EXIT, 2));
				}
				else {
					f.addCommand(new Command(lang.get(Language.OK), Command.ITEM, 1));
					f.addCommand(new Command(lang.get(Language.M_URL_S),
											lang.get(Language.M_URL_L), Command.ITEM, 2));
				}
				f.setCommandListener(parent);
				return f;
			}
			
			case GUI.HELP: {
				Form f = new Form(lang.get(Language.M_HELP_L));
				f.append(DataAccess.getTextResource("/lang/"+lang.get(Language.HELP_FILE)));
				f.addCommand(new Command(lang.get(Language.OK), Command.OK, 1));
				f.setCommandListener(parent);
				return f;
			}

			case GUI.SEL_LANG: {
				List l = new List("Select your language",List.IMPLICIT,DataAccess.getConfigEntries("/config_lang.txt"),null);
				l.setSelectCommand(new Command("Ok", Command.OK, 1));
				l.setCommandListener(parent);
				return l;
			}

			case GUI.SEL_LINE: {
				List l = new List(lang.get(Language.M_LINE_L),
							List.IMPLICIT,DataAccess.getConfigEntries("/config_lines.txt"),null);
				l.setSelectCommand(new Command(lang.get(Language.OK), Command.OK, 1));
				l.setCommandListener(parent);
				return l;
			}

			case GUI.MAIN: {
				Form f = new Form("");
				StringItem time = new StringItem(lang.get(Language.DEPARTURES_AT)+" ", "");
				StringItem siStart = new StringItem(lang.get(Language.START)+" ", "");
				StringItem siEnd = new StringItem(lang.get(Language.DESTINATION)+" ", "");
				StringItem siSt1 = new StringItem(lang.get(Language.DEPARTURE)+" ", "");
				StringItem siEn1 = new StringItem(lang.get(Language.ARRIVAL)+" ", "");
				StringItem siSt2 = new StringItem(lang.get(Language.DEPARTURE)+" ", "");
				StringItem siEn2 = new StringItem(lang.get(Language.ARRIVAL)+" ", "");

				StringItem con1 = new StringItem("", lang.get(Language.CONNECTION1));
				StringItem con2 = new StringItem("", lang.get(Language.CONNECTION2));

				Font font = Font.getFont(Font.FACE_PROPORTIONAL, Font.STYLE_BOLD|Font.STYLE_UNDERLINED,
										Font.SIZE_MEDIUM);
				con1.setFont(font);
				con2.setFont(font);
        
				f.append(siStart);
				f.append(siEnd);
				f.append(time);
				f.append(new Spacer(9000, font.getHeight()/2));
				f.append(con1);
				f.append(siSt1);
				f.append(siEn1);
				f.append(new Spacer(9000, font.getHeight()/2));
				f.append(con2);
				f.append(siSt2);
				f.append(siEn2);
				
				f.addCommand(new Command(lang.get(Language.QUIT), Command.EXIT, 1));
				f.addCommand(new Command(lang.get(Language.M_FAVORITES_S),
							lang.get(Language.M_FAVORITES_L), Command.ITEM, 1));

				f.addCommand(new Command(lang.get(Language.M_START_S),
							lang.get(Language.M_START_L), Command.ITEM, 2));
				f.addCommand(new Command(lang.get(Language.M_DESTINATION_S),
							lang.get(Language.M_DESTINATION_L), Command.ITEM, 2));

				f.addCommand(new Command(lang.get(Language.M_RETURN_S),
							lang.get(Language.M_RETURN_L), Command.ITEM, 3));
				f.addCommand(new Command(lang.get(Language.M_TIME_S),
							lang.get(Language.M_TIME_L), Command.ITEM, 3));

				f.addCommand(new Command(lang.get(Language.M_LINE_S),
							lang.get(Language.M_LINE_L), Command.ITEM, 4));
				f.addCommand(new Command(lang.get(Language.M_LANG_S),
							lang.get(Language.M_LANG_L), Command.ITEM, 4));
				f.addCommand(new Command(lang.get(Language.M_HELP_S),
							lang.get(Language.M_HELP_L), Command.ITEM, 4));

				f.addCommand(new Command(lang.get(Language.M_URL_S),
							lang.get(Language.M_URL_L), Command.ITEM, 5));
				f.addCommand(new Command(lang.get(Language.M_ABOUT_S),
							lang.get(Language.M_ABOUT_L), Command.ITEM, 5));

				f.setCommandListener(parent);
				return f;
			}
			
			case GUI.SEL_TIME: {
				List l = new List(lang.get(Language.M_TIME_L), List.IMPLICIT);
				String s[] = new ExString(lang.get(Language.IN_HOURS)).split('+');
				l.append(lang.get(Language.NOW),null);
				for(int i=1; i<=23; i++) {
					l.append(s[0]+" "+i+" "+s[1],null);
				}
				l.setSelectCommand(new Command(lang.get(Language.OK), Command.OK, 1));
				l.setCommandListener(parent);
				return l;
			}
			
			case GUI.FAVORITES:
			case GUI.SEL_START:
			case GUI.SEL_DEST:
				return new List("No data set",List.IMPLICIT);
			
			case GUI.WAIT: {
				Form f = new Form("");
				f.append(lang.get(Language.WAIT));
				return f;
			}
			
			default:
				throw new CorruptedDataException("Illegal screen");
		}
	}

	/** Sets the contents of a {@link javax.microedition.lcdui.List List}.
	* @param id		Referral to the {@link javax.microedition.lcdui.List List}
	* @param elements	Array of strings to set
	* @return 		Returns true if id is a valid referral to a List, false otherwise. */
	public boolean setList(int id, String elements[]) {
		List list;

		switch(id) {
			case GUI.SEL_LANG:
			case GUI.SEL_LINE:
				list = new List("", List.IMPLICIT, elements, null); // not used in favor of DataAccess.getConfigEntries(String).
				break;
			case GUI.FAVORITES:
				list = new List(lang.get(Language.M_FAVORITES_L), List.IMPLICIT, elements, null);
				break;
			case GUI.SEL_START:
				list = new List(lang.get(Language.M_START_L), List.IMPLICIT, elements, null);
				break;
			case GUI.SEL_DEST:
				list = new List(lang.get(Language.M_DESTINATION_L), List.IMPLICIT, elements, null);
				break;
			default:
				return false;
		}
		
		if(id != GUI.FAVORITES)
			list.setSelectCommand(new Command(lang.get(Language.OK), Command.OK, 1));
		else {
			list.setSelectCommand(new Command(lang.get(Language.LOAD), Command.ITEM, 1));
			list.addCommand(new Command(lang.get(Language.BACK), Command.ITEM, 1));
			list.addCommand(new Command(lang.get(Language.SAVE), Command.ITEM, 2));
		}

		list.setCommandListener(parent);
		uis[id] = list;
		
		return true;
	}

	/** Sets the value of a  {@link javax.microedition.lcdui.StringItem StringItem} of the main {@link javax.microedition.lcdui.Screen Screen}.
	* @param id		Must be {@link #MAIN}
	* @param element	Position of the  {@link javax.microedition.lcdui.StringItem StringItem}  to set
	* @see		#MAIN */
	public void setStringItem(int id, int element, String data) {
		try {
			if(id == GUI.MAIN) {
				Form f = (Form)getScreen(id);
				StringItem si = (StringItem)f.get(element);
				si.setText(data);
			}
		}
		catch(ClassCastException e) { e.printStackTrace(); }
		catch(IOException e) { e.printStackTrace(); }
	}

	/** Sets the current selection of a {@link javax.microedition.lcdui.List List}.
	* @param id		The {@link javax.microedition.lcdui.List List}
	* @param index	Index of the element to select */
	public void setSelection(int id, int index) {
		try {
			List l = (List)getScreen(id);
			l.setSelectedIndex(index, true);
		}
		catch(ClassCastException e) { e.printStackTrace(); }
		catch(IOException e) { e.printStackTrace(); }
	}

	/** Gets the current selection of a {@link javax.microedition.lcdui.List List}.
	* @param id		The {@link javax.microedition.lcdui.List List}
	* @return 		Returns the value of the selection or null. */
	public String getSelection(int id) throws IOException {
		try {
			List l = (List)getScreen(id);
			int index = l.getSelectedIndex();
			if(index == -1)
				return "";
			return l.getString(index);
		}
		catch(ClassCastException e) {
			e.printStackTrace();
			return null;
		}
	}

	public int getSelectionIndex(int id) throws IOException {
		try {
			List l = (List)getScreen(id);
			return l.getSelectedIndex();
		}
		catch(ClassCastException e) {
			e.printStackTrace();
			return -1;
		}
	}

	/** Sets the value of a  {@link javax.microedition.lcdui.StringItem StringItem} of the main {@link javax.microedition.lcdui.Screen Screen}.
	* @param id		Must be {@link #MAIN}
	* @param element	Position of the  {@link javax.microedition.lcdui.StringItem StringItem}  to set
	* @return 		Returns true if id is {@link #MAIN}, false otherwise.
	* @see		#MAIN */
	public String getElement(int id, int element) throws IOException {
		if(id != GUI.MAIN)
			return null;
		try {
			Form f = (Form)getScreen(id);
			StringItem si = (StringItem)f.get(element);
			return si.getText();
		}
		catch(ClassCastException e) {
			e.printStackTrace();
			return null;
		}
	}
}