/*
* Favorites.java	Version 0.0.1		2005/10/14
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

/**
 * A class to manage the favorites at runtime.
 * @version 0.0.1 14 OCT 2005
 * @author Stefan Partusch
 */
public class Favorites {
	/** This is the maximum count of favorites */
	public static final int MAXIMUM = 9;
		
	private FavoriteEntry favs[];
	private String langStart, langDest;
	
	/** @param storedFavs	String with the serialized favorites as retrieved using DataAccess.getStoredValue
	* @param langStart		Language string for the start station
	* @param langDest		Language string for the destination
	* @see DataAccess.getStoredValue(int) */
	public Favorites(String storedFavs, String langStart, String langDest) throws CorruptedDataException {
		if(storedFavs != null) {
			String favStr[] = new ExString(storedFavs).split('|'); // line:start:dest|line2:start2:dest2 ....
			favs = new FavoriteEntry[favStr.length];
			for(int i=0; i<favStr.length; i++)
				favs[i] = new FavoriteEntry(favStr[i]);
		}
		else {
			favs = new FavoriteEntry[MAXIMUM];
			for(int i=0; i<MAXIMUM; i++)
				favs[i] = new FavoriteEntry("-", "-", "-");
		}
		this.langStart = langStart;
		this.langDest = langDest;
	}

	/** Sets an new FavoriteEntry.
	* @param index	Index for the new entry. A already present entry at this index will be overwritten
	* @param entry	FavoriteEntry to set */
	public void addFavorite(int index, FavoriteEntry entry) throws CorruptedDataException {
		if((index >= 0) && (index < MAXIMUM))
			favs[index] = entry;
		else
			throw new CorruptedDataException("Invalid index");
	}

	/** Retrieves a FavoriteEntry from the favorites.
	* @param index	Index of the entry to retrieve
	* @return		The requested FavoriteEntry. */
	public FavoriteEntry getFavorite(int index) throws CorruptedDataException {
		if((index >= 0) && (index < MAXIMUM))
			return favs[index];
		else
			throw new CorruptedDataException("Invalid index");
	}
	
	
	/** Constructs a list of all favorite entries. Language strings are used to style each entry for display.
	* @return	Returns the list. */
	public String[] getFavoritesList() {
		String[] s = new String[favs.length];
		for(int i=0; i<s.length; i++)
			s[i] = new String((i+1)+". "+langStart+" "+favs[i].getStart()+"\n   "+langDest+" "+favs[i].getDestination());
		return s;
	}
	
	/** Stores the favorites in a {@link javax.microedition.rms.RecordStore RecordStore}.
	* @param da	DataAccess for the RecordStore in question */
	public void storeFavorites(DataAccess da) throws CorruptedDataException {
		String serialized = new String();
		for(int i=0; i<favs.length; i++) {
			serialized = serialized.concat(favs[i].toString());
			if(i < favs.length-1)
				serialized = serialized.concat("|");
		}
		da.storeValue(DataAccess.FAVORITES, serialized);
	}
}
