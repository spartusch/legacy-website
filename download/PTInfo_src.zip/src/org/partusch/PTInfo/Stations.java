/*
* Stations.java	Version 0.0.1		2005/10/17
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

/**
 * Provides access to station related data of a public transportation line.
 * @version 0.0.1 17 OCT 2005
 * @author Stefan Partusch
 */
public class Stations {
	private String	stations[];
	/** Times it takes to get from one station to the next in minutes (timeInMin.length == stations.length-1) */
	private int		timeInMin[];

	/** Constructor given the stations data of a public transportation line.
	* @param rawData	Stations data */
	public Stations(String rawData) throws CorruptedDataException {
		ExString exData = new ExString(rawData).stripAsciiControls(); // necessary because trim() doesn't remove line breaks on some devices
		String data[] = exData.split(';');

		if( (data.length < 2) || (data.length%2 != 0) )
			throw new CorruptedDataException("Invalid stations data");
		
		int countStations = data.length/2;
		
		stations = new String[countStations];
		timeInMin = new int[countStations-1];
		
		try {
			timeInMin[0] = Integer.parseInt(data[2].trim());
			for(int i=0,k=0; i<countStations; i++,k+=2) {
				if(i > 1) // calculate time from last station to current
					timeInMin[i-1] = Integer.parseInt(data[k].trim()) - Integer.parseInt(data[k-2].trim());
				stations[i] = data[k+1];
				if(stations[i].length() < 2)
					throw new CorruptedDataException("Missing station name");
			}
		}
		catch(NumberFormatException e) {
			throw new CorruptedDataException(e.getMessage());
		}
	}
	
	/** Returns an array with all stations of the line.
	* @return	Array with all stations. */
	public String[] getStationsList() { return stations; }

	/** Returns the corresponding name of a stations's ID.
	* @return	The station's name. */
	public String getStation(int id) { return stations[id]; }

	/** Returns the corresponding ID of a stations's name.
	* @return	The station's ID or -1. */
	public int getStationID(String s) {
		for(int i=0; i<stations.length; i++) {
		if(stations[i].equals(s))
			return i;
		}
		return -1;
	}

	/** Calculates the time it takes to get from start to dest in milliseconds.
	* @param start	ID of the station to start from
	* @param dest	ID of the destination's station
	* @return		Time to travel from start to dest in milliseconds. */
	public long getTimeInMillis(int start, int dest) {
		long time = 0;
        
		if(dest < start) {
			int buf = dest;
			dest = start;
			start = buf;
		}
        
		if(start < 0 || dest > timeInMin.length)
			return -1;
        
		for(int i=start; i<dest; i++)
			time += timeInMin[i];
        
		return time*60*1000;
	}
}
