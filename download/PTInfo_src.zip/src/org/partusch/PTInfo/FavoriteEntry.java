/*
* FavoriteEntry.java	Version 0.0.1		2005/10/14
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

/**
 * Represents one entry of the favorites.
 * @version 0.0.1 14 OCT 2005
 * @author Stefan Partusch
 */
public class FavoriteEntry {
	private String line, start, dest;
	
	/** @param data	Serialized data of the entry */
	public FavoriteEntry(String data) throws CorruptedDataException {
		int first = data.indexOf(':');
		int second = data.indexOf(':', first+1);
		if((first == -1) || (second == -1) || (data.length() < 5))
			throw new CorruptedDataException("Invalid favorite");
		Init(data.substring(0,first), data.substring(first+1,second), data.substring(second+1));
	}

	/** @param line	Public transportation line of the entry
	* @param start	Starting station
	* @param dest	Destination station */
	public FavoriteEntry(String line, String start, String dest) throws CorruptedDataException {
		Init(line, start, dest);
	}

	private void Init(String line, String start, String dest) throws CorruptedDataException {
		if(!isValid(line) || !isValid(start) || !isValid(dest))
			throw new CorruptedDataException("Invalid favorite");
		this.line = line;
		this.start = start;
		this.dest = dest;
	}
	
	/** Checks whether str is a valid value for use with FavoriteEntry. */
	private boolean isValid(String str) {
		if((str.indexOf(':') != -1) || (str.indexOf('|') != -1))
			return false;
		return true;
	}
	

	/** Checks whether the FavoriteEntry has real values set.
	* @return	Returns true if it is used and false if nothing real is set. */
	public boolean isUsed() {
		if(line.equals("-") || start.equals("-") || dest.equals("-"))
			return false;
		return true;
	}

	
	/** Serializes the FavoriteEntry.
	* @return	The serialized FavoriteEntry. */
	public String toString() { return line+":"+start+":"+dest; }

	public String getLine() { return line; }
	public String getStart() { return start; }
	public String getDestination() { return dest; }
}
