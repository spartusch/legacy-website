/*
* ExString.java	Version 0.0.1		2005/10/22
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

import java.util.Vector;

/**
 * An extended {@link java.lang.String String} class.
 * @version 0.0.1 22 OCT 2005
 * @author Stefan Partusch
 */
public class ExString {
	private String s;

	/** Create ExString from  {@link java.lang.String String} . */
	public ExString(String data) { s = data; }
	/** Create ExString from  {@link java.lang.StringBuffer StringBuffer} . */
	public ExString(StringBuffer data) { s = data.toString(); }

	/** Return current ExString as  {@link java.lang.String String} . */
	public String toString() { return s; }

	/** Splits the ExString everywhere the separator token is found.
	* @param separator	Token marking locations to split
	* @return		Array of strings. */
	public String[] split(int separator) {
		Vector v = new Vector(2);
		int start = 0;
		int end;

		while( (end = s.indexOf(separator,start)) >= 0 ) {
			v.addElement(s.substring(start,end));
			start = end + 1;
		}
        
		end = s.lastIndexOf(separator);
		if( (end > 0) && (end < s.length()-2) ) {
			String element = s.substring(end+1, s.length());
			if(element.trim().length() > 0)
				v.addElement(element);
		}
		else if(end < 0) // separator doesn't exist in s 
			v.addElement(s);
        
		v.trimToSize();
		
		String sArray[] = new String[v.size()];
		v.copyInto(sArray);

		return sArray;
	}

	/** Removes all ASCII control characters and white spaces and returns that ExString.
	* @return		ExString without ASCII control chars and space. */
	public ExString strip() {
		StringBuffer sb = new StringBuffer();

		for(int i=0; i<s.length(); i++) {
			if(s.charAt(i) > 32)
				sb.append(s.charAt(i));
		}

		return new ExString(sb);
	}
	
	/** Removes all ASCII control characters, especially LF and CR, but NOT space and returns that ExString.
	* @return		ExString without ASCII control chars. */
	public ExString stripAsciiControls() {
		StringBuffer sb = new StringBuffer();

		for(int i=0; i<s.length(); i++) {
			if(s.charAt(i) >= 32)
				sb.append(s.charAt(i));
		}

		return new ExString(sb);
	}
}
