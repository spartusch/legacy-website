/*
* DataAccess.java	Version 0.0.1		2005/10/22
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.InvalidRecordIDException;

/**
 * Provides and manages access to all external ({@link javax.microedition.rms.RecordStore RecordStore}) and internal resources.
 * @version 0.0.1 22 OCT 2005
 * @author Stefan Partusch
 */
public class DataAccess {
	/** ID for the record of the language filename */
	public static final int LANG_FILE = 1;
	/** ID for the record of the filename of the file with the public transportation line data */
	public static final int LINE_FILE = 2;
	/** ID for the record of the starting station */
	public static final int START_STATION = 3;
	/** ID for the record of the destination station */
	public static final int DEST_STATION = 4;
	/** ID for the record of the user-defined favorites */
	public static final int FAVORITES = 5;
		
	private RecordStore rs;

	/** Opens the {@link javax.microedition.rms.RecordStore RecordStore} and initializes it if necessary. closeRS() must be called! */
	public DataAccess() throws CorruptedDataException {
		try {
			rs = RecordStore.openRecordStore("PTInfoStorage", true);
			if(rs.getNumRecords() != 5) {
				rs.closeRecordStore();
				RecordStore.deleteRecordStore("PTInfoStorage");
				rs = RecordStore.openRecordStore("PTInfoStorage", true);
				byte[] dummy = new String("N//A").getBytes();
				for(int i=1; i<=5; i++)
					rs.addRecord(dummy,0,dummy.length);
			}
		}
		catch(RecordStoreException e) { throw new CorruptedDataException(e.getMessage()); }
	}

	/** Closes the {@link javax.microedition.rms.RecordStore RecordStore}. */
	public void closeRS() {
		try { rs.closeRecordStore(); }
		catch(RecordStoreException e) { e.printStackTrace(); }
	}

	/** Retrieves are stored value from the {@link javax.microedition.rms.RecordStore RecordStore}.
	* @param idRecord	ID of the value to retrieve
	* @return		Stored value or null. */
	public String getStoredValue(int idRecord) throws CorruptedDataException {
		try {
			byte data[] = rs.getRecord(idRecord);
			if(data == null)
				throw new CorruptedDataException("No data");
			String record = new String(data);
			if(record.equals("N//A"))
				return null;
			return record;
		}
		catch(RecordStoreException e) { throw new CorruptedDataException(e.getMessage()); }
	}

	/** Store a value at the {@link javax.microedition.rms.RecordStore RecordStore}.
	* @param idRecord	ID of the value to store
	* @param record	The value to store */
	public void storeValue(int idRecord, String record) throws CorruptedDataException {
		try {
			byte[] data = record.getBytes();
			rs.setRecord(idRecord, data, 0, data.length);
		}
		catch(RecordStoreException e) { throw new CorruptedDataException(e.getMessage()); }
	}


	/** Retrieve a given text file stored as an internal resource.
	* @param file	Filename and full path of the file to retrieve
	* @return	Contents of the file. */
	public static String getTextResource(String file) throws IOException {
		InputStream is = new Object().getClass().getResourceAsStream(file); // null
		if(is == null)
			throw new IOException(file+" not found");

		InputStreamReader isr;
		try {
			isr = new InputStreamReader(is, "UTF-8");
		}
		catch(UnsupportedEncodingException e) {
			isr = new InputStreamReader(is);
		}
		
		// wait until ready to read
		while(!isr.ready()) {;} // IOException

		StringBuffer data = new StringBuffer();
		int ch;
		while((ch = isr.read()) != -1) // IOException
			data.append((char)ch);

		isr.close(); // IOException
		
		// Check for BOM and remove it
		if(data.charAt(0) == 0xFEFF)
			data.deleteCharAt(0);
        
		return data.toString();
	}

	/** Retrieves all entries from a configuration file but not their values.
	* @param cfgFile	The configuration file's filename
	* @return		All entries of the file. */
	public static String[] getConfigEntries(String cfgFile) throws IOException {
		ExString data = new ExString(getTextResource(cfgFile)).stripAsciiControls();
		String entries[] = data.split(';');
		for(int i=0; i<entries.length; i++) {
			int end = entries[i].indexOf(':');
			if(end <= 0)
				throw new CorruptedDataException("Invalid configuration");
			entries[i] = entries[i].substring(0, end);
		}
		return entries;
	}
	
	/** Retrieves the value of a configuration entry.
	* @param cfgFile	The configuration file's filename
	* @param cfgEntry	The entry to retrieve.
	* @return		The value of the entry. */
	public static String getConfigValue(String cfgFile, String cfgEntry) throws IOException {
		String cfg = getTextResource(cfgFile);
		int start = cfg.indexOf(cfgEntry);
		if(start < 0)
			throw new CorruptedDataException("Cfg Entry "+cfgEntry+" not found");
		start = cfg.indexOf(':', start) + 1;
		int end = cfg.indexOf(';', start);
		if(start < 0 || end < 0)
			throw new CorruptedDataException("Invalid configuration");
		return new ExString(cfg.substring(start, end)).stripAsciiControls().toString();
	}
}
