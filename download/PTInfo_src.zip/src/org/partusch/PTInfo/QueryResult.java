/*
* QueryResult.java	Version 0.0.1		2005/10/17
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

import java.lang.Math;
import java.util.Date;
import java.util.Calendar;

/**
 * Container for the data of a concrete query. Also responsible for "styling" that data (i.e. convert it to {@link java.lang.String string}).
 * @version 0.0.1 17 OCT 2005
 * @author Stefan Partusch
 */
public class QueryResult {
	private Date	nextCon;
	private Date	afterNextCon;
	private String	lang[];
	private int 	idStart, idDest;
	private long	timeMillis, timeOffset;

	/** Constructor given a connection's starting and destination stations, the time it takes to get from start to
	* destination in milliseconds, the  {@link javax.microedition.lcdui.Date date} of the next connection and the date of the connection after the next connection.
	* @param start	Starting station
	* @param dest	Destination station
	* @param travelTime	Time from start to dest in milliseconds
	* @param next	 {@link javax.microedition.lcdui.Date Date} of the next connection
	* @param after	 {@link javax.microedition.lcdui.Date Date} of the connection after the next connection
	* @param timeOffset The offset to add to current time to get the time in question for the connections */
	public QueryResult(int start, int dest, long travelTime, Date next, Date after, long timeOffset) {
		nextCon = next;
		afterNextCon = after;
		idStart = start;
		idDest = dest;
		timeMillis = travelTime;
		this.timeOffset = timeOffset;
		lang = new String[3];
		lang[0] = new String("");
		lang[1] = new String("(in");
		lang[2] = new String("min)");
	}

	/** Returns the identifier of the starting station.
	* @return	ID of start station. */
	public int getStart() { return idStart; }

	/** Returns the identifier of the destination.
	* @return	ID of destination. */
	public int getDest() { return idDest; }

	/** Returns the Date of the next connection.
	* @return	{@link javax.microedition.lcdui.Date Date} of next connection. */
	public Date getNextCon() { return nextCon; }

	/** Returns the Date of the connection after the next connection.
	* @return	{@link javax.microedition.lcdui.Date Date} of the connection after the next connection. */
	public Date getAfterNextCon() { return afterNextCon; }

	/** Returns the next connection as a formatted {@link java.lang.String string}.
	* @return	Formatted string of the next connection. */
	public String getDepartureNext() { return createString(nextCon); }

	/** Returns the arrival time of the next connection as a formatted {@link java.lang.String string}.
	* @return	 Arrival time of next connection as a formatted string. */
	public String getArrivalNext() { return createString(new Date(nextCon.getTime() + timeMillis)); }

	/** Returns the connection after the next connection as a formatted {@link java.lang.String string}.
	* @return	Formatted string of the connection after the next connection. */
	public String getDepartureAfterNext() { return createString(afterNextCon); }

	/** Returns the arrival time of the connection after the next connection as a formatted {@link java.lang.String string}.
	* @return	Arrival time of the connection  after the next connection as a formatted string. */
	public String getArrivalAfterNext() { return createString(new Date(afterNextCon.getTime() + timeMillis)); }
	
	/** Formats the current time + the offset  as a {@link java.lang.String string}.
	* @return	Time formatted time as a string. */
	public String getTime() {
		Calendar c = Calendar.getInstance();
		c.setTime(new Date(new Date().getTime()+timeOffset));
		
		return formatTime(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
	}

	/** Formats a given {@link javax.microedition.lcdui.Date date} as a {@link java.lang.String string}.
	* @param date	{@link javax.microedition.lcdui.Date Date} to format
	* @return		The formatted string. */
	private String createString(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
        
		//Floating point is on some devices not supported -> changed from CLDC 1.1 to CLDC 1.0
		//long dur = (long)Math.ceil( ( (double)date.getTime()-new Date().getTime() )/(1000*60) );
		long dur = (date.getTime()-new Date().getTime()+35000)/(1000*60);
		int hour = c.get(Calendar.HOUR_OF_DAY);
		int min = c.get(Calendar.MINUTE);
		
		return formatTime(hour,min)+" "+lang[1]+" "+String.valueOf(dur)+" "+lang[2];
	}

	private String formatTime(int hour, int min) {
		String sHour= (hour < 10) ? "0"+String.valueOf(hour) : String.valueOf(hour);
		String sMin = (min < 10) ? "0"+String.valueOf(min) : String.valueOf(min);
        
		return sHour+":"+sMin+" "+lang[0];
	}

	/** Sets the language dependent {@link java.lang.String string} to use for formation.
	* @param ls	String containing language dependent substrings divided by '+'
	* @return	false if ls has wrong format, true otherwise. */
	public boolean setLanguage(String ls) {
		String l[] = new ExString(ls).split('+');
		if(l.length != 3)
			return false;
		lang = l;
		return true;
	}
}
