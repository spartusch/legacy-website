/*
* PTInfo.java	Version 0.0.1		2005/10/23
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

import java.io.IOException;
import java.lang.Runtime;
import java.util.Timer;
import java.util.TimerTask;
import javax.microedition.io.ConnectionNotFoundException;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;

/**
 * Public Transportation Information's main class. Responsible for the cooperation and interaction of all components.
 * @version 0.0.1 23 OCT 2005
 * @author Stefan Partusch
 */
public class PTInfo extends MIDlet implements CommandListener {
	private DataAccess	da;
	private GUI		ui;
	private PTLine		line;
	private Timer		timer;
	private Favorites	favs;
	private String		startStation, destStation, langTimeString;
	private long		timeOffset;
	private boolean		keepStations;

	public PTInfo() {
		try {
			favs = null;
			line = null;
			timer = null;
			timeOffset = 0;
			da = new DataAccess();
			String langFile = da.getStoredValue(DataAccess.LANG_FILE);
			if(langFile != null) {
				Init(langFile);
			}
			else { // LANG_FILE not set, i.e. first start of PTInfo on this device
				ui = new GUI(this, null);
				ui.setCurrentScreen(GUI.SPLASH);
			}
		}
		catch(IOException e) {
			ui = null;
			e.printStackTrace();
		}
	}

	/** Initializes language strings and creates a new GUI. The rest is kept or initialized, too. */
	private void Init(String langFile) throws IOException {
		Language lang = new Language(DataAccess.getTextResource("/lang/"+langFile));
		langTimeString = lang.get(Language.OCLOCK);
		ui = new GUI(this, lang);

		if(timer == null)
			timer = new Timer();
		
		if(favs == null)
			favs = new Favorites(da.getStoredValue(DataAccess.FAVORITES), lang.get(Language.FROM), lang.get(Language.TO));

		ui.setCurrentScreen(GUI.MAIN);
		if((line == null) || (startStation == null) || (destStation == null)) {
			String newLine = da.getStoredValue(DataAccess.LINE_FILE);
			startStation = da.getStoredValue(DataAccess.START_STATION);
			destStation = da.getStoredValue(DataAccess.DEST_STATION);
			if((startStation != null) && (destStation != null) && (newLine != null)) {
				loadLine(newLine, true);
			}
			else { // START_STATION or DEST_STATION or LINE_FILE not set
				ui.setCurrentScreen(GUI.SEL_LINE);
			}
		}
		else { // keep current stations and line
			ui.setTitle(GUI.MAIN, line.getName());
			updateData(true);
		}
	}

	/** Loads a new public transportation line. The new line will be set using PTInfo.setLine(PTLine).
	* @param newLine		Filename of the data of the new line
	* @param keepStations	Starting station and destination are not changed when true
	* @see #setLine(PTLine) */
	private void loadLine(String newLine, boolean keepStations) {
		ui.setCurrentScreen(GUI.WAIT);
		updateDisplay();
		line = null;
		this.keepStations = keepStations;
		Thread lineThread = new Thread(new PTLine(this, newLine));
		lineThread.start();
	}

	/** Callback for PTLine.run() - sets the line to be used.
	* @see PTLine.run()
	* @see  #loadLine(String, boolean) */
	public void setLine(PTLine newLine) {
		line = newLine;
		ui.setTitle(GUI.MAIN, line.getName());
		if(!keepStations || (startStation == null) || (destStation == null)) {
			startStation = line.getStation(0);
			destStation = line.getStation(line.getStationsList().length-1);
		}
		updateData(false);
	}
	
	/** Updates the displayed main data. The data is set using PTInfo.setDisplayData(QueryResult).
	* @param waitScreen	If true the waiting Screen is displayed while calculating the data
	* @see #setDisplayData(QueryResult) */
	public void updateData(boolean waitScreen) {
		if((line != null) && (ui != null)) {
			if(waitScreen) {
				ui.setCurrentScreen(GUI.WAIT);
				updateDisplay();
			}
			line.setConnection(startStation, destStation, timeOffset);
			Thread lineThread = new Thread(line);
			lineThread.start();
		}
	}
	
	/** Callback for PTLine.run() - sets the results which are displayed.
	* @see PTLine.run()
	* @see  #updateData() */
	public void setDisplayData(QueryResult qry) {
		qry.setLanguage(langTimeString);

		ui.setStringItem(GUI.MAIN, 0, startStation);
		ui.setStringItem(GUI.MAIN, 1, destStation);
		ui.setStringItem(GUI.MAIN, 2, qry.getTime());
		ui.setStringItem(GUI.MAIN, 5, qry.getDepartureNext());
		ui.setStringItem(GUI.MAIN, 6, qry.getArrivalNext());
		ui.setStringItem(GUI.MAIN, 9, qry.getDepartureAfterNext());
		ui.setStringItem(GUI.MAIN, 10, qry.getArrivalAfterNext());

		if(ui.getCurrentScreenID() == GUI.WAIT) {
			ui.setCurrentScreen(GUI.MAIN);
			updateDisplay();
		}
	}

	/** The actual command listener. Receives all commands.
	* @see javax.microedition.lcdui.CommandListener */
	public void commandAction(Command com, Displayable dis) {
		String label = com.getLabel();

		if((ui == null) && label.equals("")) {  // Alert.DISMISS_COMMAND - only matches when serious exception occured
			notifyDestroyed();
			return;
		}

		try {
			switch(ui.getCommandID(label)) {
				/* Screens */
				case GUI.CMD_LANG:
					ui.setCurrentScreen(GUI.SEL_LANG);
					break;
				case GUI.CMD_LINE:
					ui.setCurrentScreen(GUI.SEL_LINE);
					break;
				case GUI.CMD_START:
					ui.setCurrentScreen(GUI.SEL_START);
					ui.setList(GUI.SEL_START, line.getStationsList());
					ui.setSelection(GUI.SEL_START, line.getStationID(startStation));
					break;
				case GUI.CMD_DEST:
					ui.setCurrentScreen(GUI.SEL_DEST);
					ui.setList(GUI.SEL_DEST, line.getStationsList());
					ui.setSelection(GUI.SEL_DEST, line.getStationID(destStation));
					break;
				case GUI.CMD_TIME:
					ui.setCurrentScreen(GUI.SEL_TIME);
					break;
				case GUI.CMD_FAVORITES:
					ui.setCurrentScreen(GUI.FAVORITES);
					ui.setList(GUI.FAVORITES, favs.getFavoritesList());
					break;
				case GUI.CMD_HELP:
					ui.setCurrentScreen(GUI.HELP);
					break;
				case GUI.CMD_ABOUT:
					ui.setCurrentScreen(GUI.ABOUT);
					break;
				/* Actions */
				case GUI.CMD_ACCEPT:
					ui.setCurrentScreen(GUI.SEL_LANG);
					break;
				case GUI.CMD_OK:
					int screenID = ui.getCurrentScreenID();
					if((screenID == GUI.ABOUT) || (screenID == GUI.HELP))
						ui.setCurrentScreen(GUI.MAIN);
					else
						listCommandOk(screenID);
					break;
				case GUI.CMD_LOAD:
					FavoriteEntry fe = favs.getFavorite(ui.getSelectionIndex(GUI.FAVORITES));
					if(fe.isUsed()) {
						startStation = fe.getStart();
						destStation = fe.getDestination();
						loadLine(fe.getLine(), true);
					}
					else
						ui.setCurrentScreen(GUI.MAIN);
					break;
				case GUI.CMD_SAVE:
					favs.addFavorite(ui.getSelectionIndex(GUI.FAVORITES),
								new FavoriteEntry(line.getFileName(), startStation, destStation));
					ui.setList(GUI.FAVORITES, favs.getFavoritesList());
					break;
				case GUI.CMD_BACK:
					ui.setCurrentScreen(GUI.MAIN);
					break;
				case GUI.CMD_RETURN:
					String buf = startStation;
					startStation = destStation;
					destStation = buf;
					if(startStation.equals(destStation)) {
						// (Very) stupid "linguistic" joke :D
						Display.getDisplay(this).setCurrent(new Alert("Sentence joke", "This sentence no verb.", null,
										AlertType.INFO), ui.getCurrentScreen());
					}
					else
						loadLine(line.getOppositeLine(), true);
					return;
				case GUI.CMD_URL:
					try {
						if(platformRequest("http://www.partusch.de.vu")) {
							destroyApp(false);
							notifyDestroyed();
							return;
						}
					}
					catch(ConnectionNotFoundException e) {
						Display.getDisplay(this).setCurrent(new Alert("Error", "Sorry but your device can't handle URLs :-("
										,null,AlertType.ERROR), ui.getCurrentScreen());
						return;
					}
					break;
				case GUI.CMD_QUIT:
					destroyApp(false);
					notifyDestroyed();
					return;
				default:
					break;
			}
			updateDisplay();
		}
		catch(IOException e) { errorAlert(e); }
	}
	
	/** Handles the GUI.CMD_OK command received from lists.
	* @param screenID	The list which sent the command */
	private void listCommandOk(int screenID) throws IOException {
		switch(screenID) {
			case GUI.SEL_LANG:
				String langFile = DataAccess.getConfigValue("/config_lang.txt", ui.getSelection(screenID));
				Init(langFile);
				da.storeValue(DataAccess.LANG_FILE,langFile);
				return; // Init(langFile) sets current Screen, return to keep this Screen
			case GUI.SEL_LINE:
				loadLine(DataAccess.getConfigValue("/config_lines.txt",ui.getSelection(screenID)), false);
				return;
			case GUI.SEL_START:
				startStation = ui.getSelection(screenID);
				if((destStation != null) && !line.checkDirection(startStation, destStation)) {
					loadLine(line.getOppositeLine(), true);
					return;
				}
				break;
			case GUI.SEL_DEST:
				destStation = ui.getSelection(screenID);
				if((startStation != null) && !line.checkDirection(startStation, destStation)) {
					loadLine(line.getOppositeLine(), true);
					return;
				}
				break;
			case GUI.SEL_TIME:
				timeOffset = ui.getSelectionIndex(screenID)*60*60*1000;
				break;
			default:
				throw new CorruptedDataException("Screen is no List");
		}
		updateData(true);
	}

	/** Updates the display.  */
	public void updateDisplay() {
		try {
			Display.getDisplay(this).setCurrent(ui.getCurrentScreen());
			//Runtime.getRuntime().gc();
		}
		catch(IOException e) { errorAlert(e); }
	}

	public void errorAlert(Exception e) {
		ui = null;
		if(e != null)
			e.printStackTrace();
		Alert a = new Alert("Corrupted data", "Your copy of PTInfo seems corrupted and can't be executed! " +
			"Please download it again at www.partusch.de.vu", null, AlertType.ERROR);
		a.setTimeout(Alert.FOREVER);
		a.setCommandListener(this);
		Display.getDisplay(this).setCurrent(a);
	}

	/** Called when the application is ready to start/resume.
	* @see javax.microedition.midlet.MIDlet */
	public void startApp() {
		if(ui != null) {
			updateDisplay();
			if(timer != null)
				timer.schedule(new UpdateTimer(this),1000*10,1000*10);
		}
		else { errorAlert(null); }
	}

	/** Called when the application is paused.
	* @see javax.microedition.midlet.MIDlet */
	public void pauseApp() {
		if(timer != null)
			timer.cancel();
	}

	/** Called when the application is destroyed.
	* @see javax.microedition.midlet.MIDlet */
	public void destroyApp(boolean unconditional) {
		if((ui != null) && (da != null) && (favs != null)) {
			try {
				da.storeValue(DataAccess.LINE_FILE,line.getFileName());
				da.storeValue(DataAccess.START_STATION,startStation);
				da.storeValue(DataAccess.DEST_STATION,destStation);
				favs.storeFavorites(da);
			}
			catch(IOException e) { e.printStackTrace(); }
		}
		if(timer != null)
			timer.cancel();
		if(da != null)
			da.closeRS();
	}
}

/**
 * Calls PTInfo.updateData(boolean) when used as a {@link java.util.TimerTask TimerTask}. Does nothing else.
 * @version 0.0.1 22 OCT 2005
 * @author Stefan Partusch
* @see PTInfo.updateData(boolean)
 */
class UpdateTimer extends TimerTask {
	private PTInfo p;
	
	public UpdateTimer(PTInfo parent) { p = parent; }
	public void run() { p.updateData(false); }
}
