/*
* PTLine.java	Version 0.0.1		2005/10/22
*   
* Copyright 2005 Stefan Partusch
* http://www.partusch.de.vu
* 
* This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

package org.partusch.PTInfo;

import java.util.Date;

/**
 * Provides access to all data like stations and times of a public transportation line.
 * @version 0.0.1 22 OCT 2005
 * @author Stefan Partusch
 */
public class PTLine implements Runnable {
	private PTInfo		owner;
	private Stations		s[];
	private Timetable	tt[];
	private String		lineName, fileName;
	private String		oppDirLine; // filename of the opposite direction line
	private String 		startStr, destStr;
	private long		timeOffset;
	private boolean		loaded; // basically whether this PTLine has been initialized

	/** Must be inizialized by using a Thread!
	* @param owner	The owning object to receive the fully initialized line
	* @param fileName	The filename of the file with the line information */
	public PTLine(PTInfo owner, String fileName) {
		this.owner = owner;
		this.fileName = fileName;
		loaded = false;
	}

	/** @see Java.lang.Runnable.run() */
	public void run() {
		try {
			//Thread.currentThread().sleep(1000); // for testing
			if(!loaded) { // Initialize, i.e. load line
				ExString exData = new ExString(DataAccess.getTextResource("/lines/"+fileName)).stripAsciiControls();
				String data[] = exData.split('#');
		
				// get header information
				String header[] = new ExString(data[0]).split(';');
				if(header.length != 2)
					throw new CorruptedDataException("Invalid line header");	
				lineName = header[0].substring(header[0].indexOf('=')+1).trim();
				oppDirLine = header[1].substring(header[1].indexOf('=')+1).trim();

				// get stations and timetable information
				int len = data.length - 1;
				if( (len < 1) || (len%2 != 0) )
					throw new CorruptedDataException("Invalid line data");

				int conns = len/2;
				s = new Stations[conns];
				tt = new Timetable[conns];

				for(int i=0,k=1; i<conns; i++,k+=2) {
					s[i] = new Stations(data[k]);
					tt[i] = new Timetable(data[k+1]);
				}
			
				loaded = true;
				owner.setLine(this);
			}
			else { // Compute connections
				owner.setDisplayData(getNextConnections());
			}
		}
		catch(Exception e) {
			owner.errorAlert(e);
		}
	}

	/** Returns the name of the line.
	* @return	The line's name. */
	public String getName() { return lineName; }

	/** Returns the filename of the line.
	* @return	The line's filename. */
	public String getFileName() { return fileName; }

	/** Returns the filename of the line for the opposite direction of this line.
	* @return	The opposite line's filename. */
	public String getOppositeLine() { return oppDirLine; }

	/** Returns all stations of the line.
	* @return	Array of strings with the stations or null. */
	public String[] getStationsList() {
		if(!loaded)
			return null;
		return s[0].getStationsList();  // s[0] must be complete list of all stations
	}

	/** Returns the corresponding name of a stations's ID.
	* @return	The station's name or null. */
	public String getStation(int id) {
		if(!loaded)
			return null;
		return s[0].getStation(id);
	}

	/** Returns the corresponding ID of a stations's name.
	* @return	The station's ID or -1. */
	public int getStationID(String st) {
		if(!loaded)
			return -1;
		return s[0].getStationID(st);
	}

	/** Checks whether the route described by the parameters is in the direction of the line.
	* @param startStr	The starting station
	* @param destStr	The destination station
	* @return		If the directions are the same returns true, otherwise false. */
	public boolean checkDirection(String startStr, String destStr) {
		if(!loaded)
			return false;

		int start = getStationID(startStr);
		int dest = getStationID(destStr);
		
		if(start == -1)
			return false;
		if(start <= dest)
			return true;

		return false;
	}
	
	/** Sets a current connection for the line.
	* @param startStr		The starting station
	* @param destStr		The destination station
	* @param timeOffset	Offset to add to the current time in milliseconds */
	public void setConnection(String startStr, String destStr, long timeOffset) {
		this.startStr = startStr;
		this.destStr = destStr;
		this.timeOffset = timeOffset;
	}

	/** Queries the next connection and the connection after the next connection starting from the time specified by timeOffset
	* for the current connection.
	* @return	The result of the query. */
	private QueryResult getNextConnections() throws CorruptedDataException {
		if(!loaded)
			return null;

		int start = getStationID(startStr);
		int dest = getStationID(destStr);
		// Next connection:
		Date nextCon = findBestConnection(startStr,destStr,timeOffset);
		// Connection after the next connection:
		Date afterNextCon = findBestConnection(startStr,destStr,nextCon.getTime() - new Date().getTime() + 1*60*1000);

		return new QueryResult(start, dest, s[0].getTimeInMillis(start,dest), nextCon, afterNextCon, timeOffset);
	}
	
	/** Finds the very next connection amongst all possible connections of the line.
	* @param startStr		The starting station
	* @param destStr		The destination station
	* @param timeOffset	Offset to add to the current time in milliseconds
	* @return			Time of the resulting connection. */
	private Date findBestConnection(String startStr, String destStr, long timeOffset) throws CorruptedDataException {
		long conTime = -1;

		for(int i=0; i<s.length; i++) {
			int start = s[i].getStationID(startStr);
			int dest = s[i].getStationID(destStr);

			if((start != -1) && (dest != -1)) {
				// Timetable times are those of station 0;
				// curOffset is the offset to get times of start station -> to calculate the time when the connection arrives in start
				long curOffset = s[i].getTimeInMillis(0,start);
				long curCon = tt[i].getNextConnection(new Date().getTime() - curOffset + timeOffset).getTime() + curOffset;

				if( (conTime == -1) || (curCon < conTime-2*1000*60) ) // minimum difference 2 minutes
					conTime = curCon;
			}
		}
		
		if(conTime == -1)
			throw new CorruptedDataException("No connections found");
		
		return new Date(conTime);
	}
}