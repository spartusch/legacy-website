PTInfo Munich for Mobiles Source Code
by Stefan Partusch
http://www.partusch.de.vu
2005/10/25

First of all thanks for downloading PTInfo and its source code! This is actually
my very first object oriented program - and also my first program written in Java ...
so please be tolerant when judging its design and implementation ;-D

This program and the source code are released under the terms of the GNU General
Public License (GPL). The complete GPL is available as a text file called "gpl.txt"
within the source code's archive. Please mind that license!

The source itself was compiled with the Sun Java Wireless Toolkit 2.3 beta. It's
best to use the same software to compile it yourself. Find and download the toolkit
at http://www.sun.com, it's free.
To compile the source with the Java Wireless Toolkit create a new project and copy
the files from this archive into that project's directory. In the project's settings set
it to use MIDP 2.0 and CLDC 1.0 (or newer). That's it :-)

If you have questions about the usage of PTInfo or the data format used, check out
the documentation of PTInfo available at www.partusch.de.vu.